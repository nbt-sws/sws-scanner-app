# SwibSwap Design Handoff v2

**For:** I1NOV (Possawat Pittrapan)
**From:** BoBoBoA420 — NBT Collectibles
**Last updated:** 28 Apr 2026
**Spec version:** 2.0

---

## What this package is

This is the design handoff for **SwibSwap** — the unified mobile + web product for buying, selling, and auctioning trading cards in Thailand. v2 of the spec adds the auction subsystem, the unified mobile app architecture, and the share components for Facebook / LINE / Messenger.

If you read v1 (the original 12-page web spec), this v2 is a superset — keep v2, archive v1.

---

## The product, in one paragraph

SwibSwap is one mobile app (Google Play + App Store) + one web product (swibswap.com). Same login, same vault, same identity across both surfaces. The mobile app has 5 bottom tabs: **Scan / Vault / Browse / Auctions / Profile**. Scanning is the differentiator (SwibScan AI identifies card → rarity → grading → market value via eBay sold history). The marketplace lets users sell cards as fixed-price listings or run auctions (single card, bundle, or up-to-18-card "Vault Auction" folders). Sellers share auctions to Facebook / LINE / Messenger via auto-generated composite images. KYC verification is required for both bidders and sellers. Domestic shipping only via Thai Post EMS.

---

## What's in this package

```
SwibSwap_Design_Handoff_v2/
├── README_v2.md                       ← you're here
├── SwibSwap_Design_Spec_v2.md         ← the spec (Markdown source of truth)
├── SwibSwap_Design_Spec_v2.docx       ← Word version (in Response 2)
├── SwibSwap_Design_Spec_v2.pdf        ← printable PDF (in Response 2)
├── design_tokens_v2.json              ← Figma Tokens Studio compatible
└── pages/                             ← standalone HTML mockups (in Response 2)
    ├── web/                           ← 20 web screen HTMLs
    ├── mobile/                        ← 22 mobile screen HTMLs
    └── share/                         ← 10 share-flow mockups
```

**Read order recommendation:**
1. This README (5 min) — orientation
2. Spec section 1-3 (15 min) — architecture, design system, components
3. Open `design_tokens_v2.json` in your IDE alongside the spec
4. Spec section 4 (the auction subsystem) (30 min) — the bulk of v2's new content
5. `pages/` HTML mockups when you start building specific screens (reference, not read-through)

---

## What's new vs v1

| Area | v1 | v2 |
|---|---|---|
| Product surface | Web only (swibswap.com) | Web + unified mobile app |
| Pages documented | 12 web | 20 web + 22 mobile + 10 share |
| Auction subsystem | Not covered | Fully designed — 30+ screens |
| Vault Auctions | Not covered | Mode A (folder) + Mode B (bundle) |
| Share to social | Not covered | FB / LINE / Messenger flows |
| Composite generator | Not covered | 1080×1350 photo-only menu format |
| KYC system | Not covered | Pending / Approved / Denied states |
| Payment failure recovery | Not covered | 24h grace + 3-strike system |
| Bid retraction policy | Not covered | eBay-style policy + UI |
| Cancellation policy | Not covered | Penalty system + UI |
| Mobile architecture | N/A | Bottom tab nav (Scan/Vault/Browse/Auctions/Profile) |

---

## Phase 1 implementation priorities

**Build order** for the dev (you):

**Week 1-2: Phase 1 — SwibScan v13 (mobile app foundation)**
- Rebrand existing v12 SwibScan codebase to "SwibSwap"
- Implement bottom tab nav (Scan / Vault / Browse / Auctions / Profile)
- Scan tab: max-resolution camera (4K/60fps) + Google Vision OCR + Claude Haiku rarity detection
- Vault tab: persistent SwibsVault collection management
- Other tabs: stub screens with "Coming soon" messaging
- Browse + Auctions tabs read from eBay Browse API only (read-only marketplace data)

**Week 3-4: Phase 2 — eBay integration**
- eBay Browse API connected (production keyset already approved + exemption granted)
- Apify scrapers for additional pricing data
- Supabase caching layer
- Show real eBay sold-history pricing on each scanned card

**Week 5-6: Phase 3 — Auth + persistent vault**
- Supabase auth (Apple, Google, LINE OAuth)
- User accounts, KYC flow, profile management
- Persistent SwibsVault per user

**Week 7-10: Phase 4 — SwibSwap.com integration**
- Web product live (uses v1 spec + this v2's auction subsystem)
- Shared auth between mobile + web
- "List on SwibSwap" goes live in mobile Scan tab
- Auction subsystem built per this spec

**Week 11-12: Phase 5 — Subscriptions**
- RevenueCat integration for iOS/Android
- Stripe for web
- Pro / Elite tier paywalls

---

## Critical implementation notes

### 1. Card photo aspect ratio is sacred

TCG cards are 5:7 portrait (~63mm × 88mm). **Never crop card photos to 1:1 square.** This includes:
- Vault Auction composite images (slots are 5:7)
- Listing thumbnails on web/mobile
- Vault display tiles
- Share component previews

If you find yourself writing `aspect-ratio: 1/1` on a card image container, stop and verify it shouldn't be `5/7`.

### 2. Auction prices are LOCKED — no PromptPay discount on auctions

Fixed-price listings give buyers a 5% PromptPay discount vs credit card. **Auctions do not.** Both PromptPay and credit card pay the same final amount on auctions. SwibSwap absorbs the ~2.5% CC processing fee on auctions. Mockups A4 (win confirmation) make this explicit.

### 3. Vault Auction max is 18 cards

This is a hard cap. UI should disable the "Add card" button when the seller has 18 cards in their Vault Auction. Min is 1 card.

### 4. The composite image generator is server-side

The auto-generated 1080×1350 composite for Vault Auction Facebook shares must be server-side (Node.js + Sharp library, or Python + Pillow). Cannot be browser-side because:
- Browser image generation is unreliable across iOS Safari / Android Chrome / desktop
- Browser image generation can't reliably embed custom fonts
- Server generation is < 2.5 sec and produces consistent output
- Server can cache generated composites (vault_auction_id → composite_url)

The composite is **photo-only** — no text overlays except: SwibSwap logo header, slot number badges (01-18), end-time pill, master URL footer, and "Details in caption ↑" hint. All card metadata (code, name, rarity, language, price) lives in the FB caption text only.

### 5. SwibBid auto-bid cuts off 5 minutes before end — this is non-negotiable

No anti-snipe time extension. Hard close. SwibBid (proxy bidding) accepts new max-bids until T-5min. After T-5min, bidders must manually place bids using the standard increment table. Auction closes at exact end time regardless of activity.

### 6. KYC is required for BOTH bidders and sellers

This is unusual for marketplaces but required for SwibSwap because:
- Thailand AML compliance for high-value transactions
- Trust building for the platform's first year
- Fraud prevention on both sides

Bidders who haven't completed KYC see auctions but cannot bid. Sellers who haven't completed KYC cannot create listings or auctions. Browse + watchlist work without KYC.

### 7. Network configuration constraints

- CSP allowlist: `cdnjs.cloudflare.com`, `esm.sh`, `cdn.jsdelivr.net`, `unpkg.com` only
- No third-party fonts beyond what Inter/SF Pro/system can provide
- No external image CDNs except: Supabase Storage (your auth-controlled), eBay's image URLs (rendered via proxy if needed)

### 8. Bottom-sheet pattern is the mobile modal idiom

Mobile destructive actions (cancel auction, retract bid, win confirmation, payment failure) use bottom sheets, NOT centered modal dialogs. Reasons:
- Native iOS/Android idiom — users recognize it instantly
- Drag-handle at top makes dismissibility obvious
- Parent screen blurs to focus attention without being lost
- Better thumb ergonomics than centered modals

Use centered modals on web only.

---

## Tech stack expectations

These are recommendations, not prescriptions — pick what works for your dev pace:

| Layer | Recommendation | Alternative |
|---|---|---|
| Mobile app | React Native + Expo | Native iOS Swift + Android Kotlin |
| Web frontend | Next.js 14+ App Router | Vite + React |
| Auth | Supabase Auth | Auth0 |
| Database | Supabase Postgres | PlanetScale + custom auth |
| Image generation | Node.js + Sharp | Python + Pillow + Lambda |
| Payment | Omise (PromptPay + cards) | 2C2P |
| Subscriptions | RevenueCat (mobile) + Stripe (web) | Direct integrations |
| Card AI | Claude Haiku 4.5 + Google Vision OCR | OpenAI Vision (slower) |
| Hosting | Vercel (web) + Expo EAS (mobile) | AWS Amplify |

The current SwibScan v12 code already uses some of this stack — keep what works.

---

## What's NOT in this spec

Things you'll need to figure out or design as you go:

- **Backend data models** — I designed the UI; you design the schema. Reference the visible state in mockups (auction has: id, seller_id, card_id, starting_bid, current_bid, end_time, increment_pct, rounding, status, bid_history, etc.)
- **Push notifications** — copy and timing for: outbid notification, auction ending soon, you won, payment failed, item shipped, KYC status change
- **Email templates** — order confirmations, dispute resolution, account changes
- **Admin dashboard** — for handling KYC reviews, dispute resolution, fee adjustments, fraud flags
- **Analytics integration** — PostHog or Mixpanel for understanding user funnel
- **Customer support** — Intercom or similar for support tickets

These are deliberately out of scope for design — they're either backend-only or operational concerns.

---

## Questions while building

If something in the spec is ambiguous or contradicts itself, default to:
1. The visible mockup over written description
2. The mobile pattern over web (mobile is harder to fix in production)
3. The auction-specific rule over general marketplace rule
4. User safety / clarity over engineering convenience

If you find a real conflict, ping me and I'll adjudicate.

---

## Version control

This handoff is **v2.0**. If we add more screens or change major patterns later:
- Bug fixes to existing patterns: increment minor (v2.1, v2.2...)
- New screens or features: increment major (v3.0)
- Always include changelog in README updates

---

## Credits

- Design + product: BoBoBoA420 with Claude
- Visual aesthetic: hybrid light/dark theme, pink + periwinkle gradient
- Reference: eBay (auction mechanics), Carousell (mobile-first marketplace), Mercari (KYC flow), Facebook Marketplace (TCG group culture)

Build something good. Ship fast. We'll iterate.
