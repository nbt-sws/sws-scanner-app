// ─── Rendering functions ──────────────────────────────────────────────────────
// These read global `state`, `C`, `bsaRates` set by ui.js.
// They produce HTML strings or update specific DOM nodes — no calculation logic.

// ─── Hop tier selector (compact) ─────────────────────────────────────────────
function renderHopTierBtns(activeTier, hopIdx) {
  return `<div class="cbn-tier-btns">` +
    ['user', 'silver', 'gold', 'platinum'].map(t =>
      `<button class="cbn-tier${activeTier === t ? ' active-' + t : ''}"
        onclick="setHopTier(${hopIdx},'${t}')">${t === 'platinum' ? 'Pt' : t[0].toUpperCase()}</button>`
    ).join('') + `</div>`;
}

function renderHopSellerTierBtns(activeTier, hopIdx) {
  return `<div class="cbn-tier-btns">` +
    ['silver', 'gold', 'platinum'].map(t =>
      `<button class="cbn-tier${activeTier === t ? ' active-' + t : ''}"
        onclick="setHopSellerTier(${hopIdx},'${t}')">${t === 'platinum' ? 'Pt' : t[0].toUpperCase()}</button>`
    ).join('') + `</div>`;
}

// ─── Hop tx-type / payment toggle row ────────────────────────────────────────
function renderHopToggleBtns(activeVal, hopIdx, fnName, options) {
  return `<div class="cbn-toggle-btns">` +
    options.map(([val, label, cls]) =>
      `<button class="cbn-toggle${activeVal === val ? ' ' + cls : ''}"
        onclick="${fnName}(${hopIdx},'${val}')">${label}</button>`
    ).join('') + `</div>`;
}

// ─── Consign Chain Builder ────────────────────────────────────────────────────
function renderChainBuilder(chainHops, markup, C) {
  const numHops    = chainHops.length;
  const nodeColors = ['#8E44AD', '#2980B9', '#16A085', '#C0392B', '#1ABC9C', '#7F8C8D'];
  const subPaybackProportion = C.consignExtraRate > 0 ? C.consignPayback / C.consignExtraRate : 0;
  const showSubPayback = state.subsequentPayback && numHops > 1;
  const fbMode = chainHops[numHops - 1].buyerMode || 'buyout';

  const txTypeOpts  = [['buysell','B/S','active-buysell'],['auction','Auct','active-auction']];
  const paymentOpts = [['cc','CC','active-cc'],['pp','PP','active-pp']];

  // Seller's card block: Tx type (seller's choice) + Days/Rate. No payment.
  function saleBlock(hopIdx, daysRemaining, rate) {
    const tx = chainHops[hopIdx].txType || state.txType;
    return `
      <div class="cbn-row"><span class="cbn-lbl">Tx type</span>
        ${renderHopToggleBtns(tx, hopIdx, 'setHopTxType', txTypeOpts)}</div>
      <div class="cbn-row"><span class="cbn-lbl">Days / Rate</span>
        <div class="cbn-rate-inline">
          <input type="number" class="cbn-days" value="${daysRemaining}"
            min="1" max="7" step="1" oninput="setHopDays(${hopIdx},this.value)">
          <strong class="pos" style="font-size:11px;white-space:nowrap;">${fmtPct(rate)}</strong>
        </div></div>`;
  }

  // Buyer's payment row for a given hop index.
  function paymentRow(hopIdx) {
    const pay = chainHops[hopIdx].payment || state.payment;
    return `<div class="cbn-row"><span class="cbn-lbl">Payment</span>
      ${renderHopToggleBtns(pay, hopIdx, 'setHopPayment', paymentOpts)}</div>`;
  }

  let html = `<div class="cbn-nodes">`;

  // ── Store A node ─────────────────────────────────────────────────────────────
  const rate0 = getConsignRate(chainHops[0].daysRemaining, C);
  const storeSellerTier = chainHops[0].sellerTier || 'platinum';
  html += `
    <div class="cbn cbn-storea">
      <div class="cbn-header">📦 Store A <span class="cbn-tag">Lister</span></div>
      <div class="cbn-row"><span class="cbn-lbl">Tier</span>
        ${renderHopSellerTierBtns(storeSellerTier, 0)}</div>
      ${saleBlock(0, chainHops[0].daysRemaining, rate0)}
      ${(numHops > 1 || fbMode !== 'buyout') ? `
      <div class="cbn-row cbn-payback"><span class="cbn-lbl">+ Payback</span>
        <strong style="color:#8E44AD">${fmtPct(C.consignPayback)}</strong></div>` : ''}
    </div>`;

  // ── Intermediate reseller nodes ───────────────────────────────────────────────
  for (let i = 1; i < numHops; i++) {
    const hop           = chainHops[i];
    const rate          = getConsignRate(hop.daysRemaining, C);
    const hopSubPayback = subPaybackProportion * rate;
    const col           = nodeColors[i - 1] || '#555';
    const buyingTier    = chainHops[i - 1].buyerTier || 'gold';
    html += `
    <div class="cbn-arrow">›</div>
    <div class="cbn cbn-reseller" style="border-color:${col}">
      <div class="cbn-header" style="color:${col}">🔄 Reseller ${i}
        <button class="cbn-del" onclick="deleteConsignee(${i})">✕</button></div>
      <div class="cbn-sub-label">As buyer</div>
      <div class="cbn-row"><span class="cbn-lbl">Tier</span>
        ${renderHopTierBtns(buyingTier, i - 1)}</div>
      ${paymentRow(i - 1)}
      <div class="cbn-divider"></div>
      <div class="cbn-sub-label">Resells as</div>
      ${saleBlock(i, hop.daysRemaining, rate)}
      ${showSubPayback && (i < numHops - 1 || fbMode !== 'buyout') ? `<div class="cbn-row cbn-payback"><span class="cbn-lbl">+ Payback</span>
        <strong style="color:#2980B9">${fmtPct(hopSubPayback)}</strong></div>` : ''}
    </div>`;
  }

  // ── Final Buyer node ──────────────────────────────────────────────────────────
  const fbHopIdx  = numHops - 1;
  const fbHop     = chainHops[fbHopIdx];
  const fbTier    = fbHop.buyerTier || 'gold';
  const fbDays    = fbHop.buyerDays || 7;
  const fbExpRate = fbMode === 'consignExpire' ? getConsignRate(fbDays, C) : 0;
  const buyerModeOpts = [['buyout','Buyout','active-buysell'],['consignExpire','Consign & Exp','active-auction']];
  html += `
    <div class="cbn-arrow">›</div>
    <div class="cbn cbn-finalbuyer">
      <div class="cbn-header">🛒 Final Buyer</div>
      <div class="cbn-row"><span class="cbn-lbl">Mode</span>
        ${renderHopToggleBtns(fbMode, fbHopIdx, 'setFinalBuyerMode', buyerModeOpts)}</div>
      ${fbMode === 'consignExpire' ? `
      <div class="cbn-row"><span class="cbn-lbl">Exp Days / Rate</span>
        <div class="cbn-rate-inline">
          <input type="number" class="cbn-days" value="${fbDays}"
            min="1" max="7" step="1" oninput="setFinalBuyerDays(this.value)">
          <strong class="pos" style="font-size:11px;white-space:nowrap;">${fmtPct(fbExpRate)}</strong>
        </div></div>` : ''}
      <div class="cbn-divider"></div>
      <div class="cbn-sub-label">As buyer</div>
      <div class="cbn-row"><span class="cbn-lbl">Tier</span>
        ${renderHopTierBtns(fbTier, fbHopIdx)}</div>
      ${paymentRow(fbHopIdx)}
    </div>`;

  html += `</div>`;

  const canAdd = numHops < 7;
  html += `<div class="cbn-actions">
    <button class="cbn-add-btn" onclick="addConsignee()" ${canAdd ? '' : 'disabled'}>
      + Add Consignee (${numHops}/7)
    </button>
    ${numHops > 1 ? `<span class="cbn-markup-row">
      Reseller markup: <input type="number" id="markup" class="cbn-markup-input"
        value="${Math.round(markup * 100)}" min="0" max="100" step="1"
        oninput="recalc()">%
    </span>` : `<input type="hidden" id="markup" value="${Math.round(markup * 100)}">`}
    <label class="cbn-payback-opt" style="font-size:12px;display:flex;align-items:center;gap:6px;margin-top:8px;cursor:pointer;">
      <input type="checkbox" onchange="toggleSubsequentPayback(this.checked)"
        ${state.subsequentPayback ? 'checked' : ''}>
      Give subsequent consignors payback
      <span style="color:#2980B9;font-weight:700;">(${fmtPct(subPaybackProportion)} of each hop's consign rate)</span>
    </label>
  </div>`;

  return html;
}

// ─── 7-Day Decay Graph ────────────────────────────────────────────────────────
// Rendered Day 7 (left/max) → Day 1 (right/min) to match chain order.
function renderDecayGraph(C) {
  const rates   = C.consignDecayRates || DEFAULT_CONSIGN_DECAY;
  const maxRate = Math.max(...rates);
  let cols = '';
  for (let d = 7; d >= 1; d--) {
    const r   = rates[d - 1];
    const pct = maxRate > 0 ? (r / maxRate * 100) : 0;
    cols += `
      <div class="dg-col">
        <div class="dg-val" id="decayValLabel${d}">${(r * 100).toFixed(2)}%</div>
        <div class="dg-track">
          <div class="dg-fill" id="decayFill${d}" style="height:${pct}%"></div>
        </div>
        <input type="number" id="decayDay${d}" class="dg-input"
          value="${(r * 100).toFixed(2)}" min="0.01" max="20" step="0.01"
          oninput="updateDecayRate(${d - 1}, this.value)">
        <div class="dg-label">Day ${d}</div>
      </div>`;
  }
  return `<div class="dg-graph">${cols}</div>
    <button class="reset-btn" onclick="resetDecayRates()">↺ Reset to Exponential Default</button>`;
}

// ─── Shared building blocks ───────────────────────────────────────────────────
function calcLine(label, formula, value, cls = '') {
  return `<div class="calc-line">
    <span class="cl">${label}</span>
    <span class="cf">${formula}</span>
    <span class="cv ${cls}">${value}</span>
  </div>`;
}
function calcTotal(label, value, cls = '') {
  return `<div class="calc-total-line">
    <span>${label}</span>
    <span class="${cls}">${value}</span>
  </div>`;
}
function renderRow(label, value, cls = '', labelCls = '') {
  return `<div class="row-item ${cls}">
    <span class="item-label ${labelCls}">${label}</span>
    <span class="item-value">${value}</span>
  </div>`;
}

// ─── Buyer card ───────────────────────────────────────────────────────────────
function renderBuyer(r, price) {
  const rows = [];
  rows.push(renderRow('Listed Price (P0)', fmt(price)));
  rows.push(renderRow(
    r.isAuction ? `Auction Fee (${state.buyerTier})` : `Buyer Fee (${state.buyerTier})`,
    fmt(r.buyerFeeShare)));
  if (r.consignExtra > 0)
    rows.push(renderRow(`Consign Delivery Fee (+${fmtPct(C.consignExtraRate)})`, fmt(r.consignExtra)));
  rows.push(renderRow('Shipping', fmt(r.shippingCharge)));
  if (r.ppDiscountAmt > 0)
    rows.push(renderRow('PromptPay Discount', fmt(-r.ppDiscountAmt), '', 'pos'));
  rows.push(renderRow('TOTAL YOU PAY', fmt(r.buyerTotal), 'total'));
  return rows.join('');
}

// ─── Seller card ──────────────────────────────────────────────────────────────
function renderSeller(r, price) {
  const rows = [];
  rows.push(renderRow('Listed Price (P0)', fmt(price)));
  if (r.isAuction && r.sellerFeeShare === 0)
    rows.push(renderRow('Seller Fee (Auction — free to list)', '฿0.00'));
  else if (r.isAuction)
    rows.push(renderRow(`Seller Fee (Auction, ${fmtPct(C.auctionSellerFeeRate)} of BSA rate)`, fmt(-r.sellerFeeShare), '', 'neg'));
  else
    rows.push(renderRow(`Seller Fee (${state.sellerTier})`, fmt(-r.sellerFeeShare), '', 'neg'));
  if (r.consignPayback > 0)
    rows.push(renderRow(`Consign Payback (+${fmtPct(C.consignPayback)})`, fmt(r.consignPayback), '', 'pos'));
  rows.push(renderRow('Net Received', fmt(r.sellerReceives)));
  rows.push(renderRow('Estimated Cost', fmt(-state.sellerCost), '', 'neg'));
  const gm = r.sellerGM != null ? ` (${fmtPct(r.sellerGM)})` : '';
  rows.push(renderRow('Gross Profit' + gm, fmt(r.sellerProfit), 'total', r.sellerProfit >= 0 ? 'pos' : 'neg'));
  return rows.join('');
}

// ─── Platform card ────────────────────────────────────────────────────────────
function renderPlatform(r) {
  const rows = [];
  if (r.isAuction) {
    rows.push(renderRow(`Auction Buyer Fee (${state.buyerTier})`, fmt(r.buyerFeeShare)));
    if (r.sellerFeeShare > 0)
      rows.push(renderRow(`Auction Seller Fee (${fmtPct(C.auctionSellerFeeRate)} of BSA rate)`, fmt(r.sellerFeeShare)));
  } else {
    rows.push(renderRow(`Buyer Fee (${state.buyerTier})`, fmt(r.buyerFeeShare)));
    rows.push(renderRow(`Seller Fee (${state.sellerTier})`, fmt(r.sellerFeeShare)));
  }
  if (r.consignExtra > 0)
    rows.push(renderRow(`Consign Delivery Fee (${fmtPct(C.consignExtraRate)})`, fmt(r.consignExtra)));
  rows.push(renderRow('Total Fee Revenue', fmt(r.totalFeeRevenue)));
  if (r.consignPayback > 0)
    rows.push(renderRow(`− Consign Payback to Seller (${fmtPct(C.consignPayback)})`, fmt(-r.consignPayback), '', 'neg'));
  if (r.shippingCollected > 0) {
    rows.push(renderRow('+ Shipping Collected', fmt(r.shippingCollected), '', 'pos'));
    rows.push(renderRow('− Courier Cost', fmt(-r.shippingCost), '', 'neg'));
    if (r.shippingNet !== 0)
      rows.push(renderRow('  Shipping Net', fmt(r.shippingNet), '', r.shippingNet >= 0 ? 'pos' : 'neg'));
  } else {
    rows.push(renderRow('Shipping (Deferred)', '฿0.00 — Consign 7-Day'));
  }
  rows.push(renderRow(
    `− Payment Fee (${state.payment === 'cc' ? 'CC ' + fmtPct(C.ccFee) : 'PP ' + fmtPct(C.ppFee)})`,
    fmt(-r.paymentFee), '', 'neg'));
  rows.push(renderRow(`− VAT on Fees (${fmtPct(C.vat)})`, fmt(-r.vatOnFee), '', 'neg'));
  if (state.payment === 'pp' && r.ppDiscountAmt > 0)
    rows.push(renderRow(`− PP Discount to Buyer (${fmtPct(C.ppDisc)})`, fmt(-r.ppDiscountAmt), '', 'neg'));
  rows.push(renderRow(
    `NET PROFIT (${fmtPct(r.platformGM)})`, fmt(r.platformNet),
    'total', r.platformNet >= 0 ? 'pos' : 'neg'));
  return rows.join('');
}

// ─── Chain-mode summary cards ─────────────────────────────────────────────────
// These replace the standard 3-card dashboard when deliveryMode is 'consign',
// showing the final buyer, Store A, and the chain-level platform rollup.

function renderBuyerChain(transactions, C) {
  const finalT = transactions[transactions.length - 1];
  const tx     = finalT.tx;
  const price  = finalT.price;
  const hops   = transactions.length;
  const feeRateStr = tx.buyerFeeRate != null ? fmtPct(tx.buyerFeeRate) : 'Flat';
  const rows   = [];
  rows.push(renderRow(
    hops > 1 ? `Listed Price (${hops}-hop chain, last hop)` : 'Listed Price (Direct)',
    fmt(price)));
  rows.push(renderRow(`Buyer Fee (${state.buyerTier}, ${feeRateStr})`, fmt(tx.buyerFeeShare)));
  if (tx.consignExtra > 0)
    rows.push(renderRow(`Consign Fee (+${fmtPct(finalT.consignRate)}, Day ${finalT.daysRemaining})`, fmt(tx.consignExtra)));
  rows.push(renderRow('Shipping', fmt(tx.shippingCharge)));
  if (tx.ppDiscountAmt > 0)
    rows.push(renderRow('PromptPay Discount', fmt(-tx.ppDiscountAmt), '', 'pos'));
  rows.push(renderRow('TOTAL FINAL BUYER PAYS', fmt(tx.buyerTotal), 'total'));
  return rows.join('');
}

function renderSellerChain(transactions, origPrice, sellerCost, C) {
  const firstT     = transactions[0];
  const tx         = firstT.tx;
  const feeRateStr = tx.sellerFeeRate != null ? fmtPct(tx.sellerFeeRate) : 'Flat';
  const rows       = [];
  rows.push(renderRow('Listed Price (Original)', fmt(origPrice)));
  if (tx.isAuction && tx.sellerFeeShare === 0)
    rows.push(renderRow('Seller Fee (Auction — free to list)', '฿0.00'));
  else if (tx.isAuction)
    rows.push(renderRow(`Seller Fee (Auction, ${fmtPct(C.auctionSellerFeeRate)} of BSA rate)`, fmt(-tx.sellerFeeShare), '', 'neg'));
  else
    rows.push(renderRow(`Seller Fee (${state.sellerTier}, ${feeRateStr})`, fmt(-tx.sellerFeeShare), '', 'neg'));
  if (tx.consignPayback > 0) {
    const paybackRate = tx.consignPayback / origPrice;
    rows.push(renderRow(`Consign Payback (+${fmtPct(paybackRate)})`, fmt(tx.consignPayback), '', 'pos'));
  }
  rows.push(renderRow('Net Received', fmt(tx.sellerReceives), 'total'));
  if (sellerCost > 0) {
    const profit = tx.sellerReceives - sellerCost;
    const gm     = ` (${fmtPct(profit / sellerCost)})`;
    rows.push(renderRow('Estimated Cost', fmt(-sellerCost), '', 'neg'));
    rows.push(renderRow(`Gross Profit${gm}`, fmt(profit), 'total', profit >= 0 ? 'pos' : 'neg'));
  }
  return rows.join('');
}

function renderPlatformChain(transactions, C) {
  const totalBuyerFee   = transactions.reduce((s, t) => s + t.tx.buyerFeeShare,  0);
  const totalSellerFee  = transactions.reduce((s, t) => s + t.tx.sellerFeeShare, 0);
  const totalConsign    = transactions.reduce((s, t) => s + t.tx.consignExtra,   0);
  const totalFeeRev     = totalBuyerFee + totalSellerFee + totalConsign;
  const totalPayback    = transactions.reduce((s, t) => s + t.tx.consignPayback, 0);
  const totalPaymentFee = transactions.reduce((s, t) => s + t.tx.paymentFee,     0);
  const totalVat        = transactions.reduce((s, t) => s + t.tx.vatOnFee,       0);
  const totalPpDisc     = transactions.reduce((s, t) => s + t.tx.ppDiscountAmt,  0);
  const shipNet         = C.shippingCharge - C.shippingCost;
  const totalPlatform   = transactions.reduce((s, t) => s + t.adjustedPlatNet,   0);
  const finalBuyerPaid  = transactions[transactions.length - 1].tx.buyerTotal;
  const platformGM      = finalBuyerPaid > 0 ? totalPlatform / finalBuyerPaid : 0;
  const hops            = transactions.length;
  const rateRange       = hops > 1
    ? `${fmtPct(Math.min(...transactions.map(t => t.consignRate)))}–${fmtPct(Math.max(...transactions.map(t => t.consignRate)))}`
    : fmtPct(transactions[0].consignRate);

  const rows = [];
  rows.push(renderRow(`Buyer Fees (${hops} hop${hops > 1 ? 's' : ''})`,  fmt(totalBuyerFee),  '', 'pos'));
  rows.push(renderRow(`Seller Fees (${hops} hop${hops > 1 ? 's' : ''})`, fmt(totalSellerFee), '', 'pos'));
  rows.push(renderRow(`Consign Fees (${rateRange})`,                      fmt(totalConsign),   '', 'pos'));
  rows.push(renderRow('Total Fee Revenue', fmt(totalFeeRev), 'total'));
  if (totalPayback > 0)
    rows.push(renderRow('− Payback to Consignors', fmt(-totalPayback), '', 'neg'));
  rows.push(renderRow(`+ Shipping Net (1 delivery)`, fmt(shipNet), '', shipNet >= 0 ? 'pos' : 'neg'));
  rows.push(renderRow(
    `− ${state.payment === 'cc' ? 'CC' : 'PP'} Processing Fees`, fmt(-totalPaymentFee), '', 'neg'));
  rows.push(renderRow(`− VAT on Fees (${fmtPct(C.vat)})`, fmt(-totalVat), '', 'neg'));
  if (totalPpDisc > 0)
    rows.push(renderRow('− PP Discount to Buyers', fmt(-totalPpDisc), '', 'neg'));
  rows.push(renderRow(
    `CHAIN NET (GM ${fmtPct(platformGM)})`, fmt(totalPlatform),
    'total', totalPlatform >= 0 ? 'pos' : 'neg'));
  return rows.join('');
}

function renderStatsChain(chainResult, C) {
  const { transactions }  = chainResult;
  const finalTx           = transactions[transactions.length - 1];
  const firstTx           = transactions[0];
  const totalPlatform     = transactions.reduce((s, t) => s + t.adjustedPlatNet, 0);
  const totalConsignFees  = transactions.reduce((s, t) => s + t.tx.consignExtra,  0);
  const finalBuyerPaid    = finalTx.tx.buyerTotal;
  const platformGM        = finalBuyerPaid > 0 ? totalPlatform / finalBuyerPaid : 0;
  const hops              = transactions.length;
  const paybackRate       = firstTx.tx.consignPayback > 0
    ? firstTx.tx.consignPayback / transactions[0].price : 0;
  const paybackNote       = paybackRate > 0
    ? `After fee + ${fmtPct(paybackRate)} payback` : 'After seller fee';

  return `
    <div class="stat-box">
      <div class="stat-label">Final Buyer Pays</div>
      <div class="stat-value">${fmt(finalBuyerPaid)}</div>
      <div class="stat-sub">${state.payment === 'cc' ? 'Credit Card' : 'PromptPay'} · incl. shipping</div>
    </div>
    <div class="stat-box">
      <div class="stat-label">Store A Receives</div>
      <div class="stat-value">${fmt(firstTx.tx.sellerReceives)}</div>
      <div class="stat-sub">${paybackNote}</div>
    </div>
    <div class="stat-box highlight-box">
      <div class="stat-label">Platform Net (${hops} hop${hops > 1 ? 's' : ''})</div>
      <div class="stat-value">${fmt(totalPlatform)}</div>
      <div class="stat-sub">GM ${fmtPct(platformGM)}</div>
    </div>
    <div class="stat-box">
      <div class="stat-label">Consign Fees Collected</div>
      <div class="stat-value">${fmt(totalConsignFees)}</div>
      <div class="stat-sub">${hops} hop${hops > 1 ? 's' : ''} · variable rates</div>
    </div>`;
}

// ─── Stat boxes ───────────────────────────────────────────────────────────────
function renderStats(r) {
  const txLabel  = r.isAuction ? 'Auction' : 'Buy-Sell';
  const dlvLabel = r.isConsign ? 'Consign 7-Day' : 'Deliver Now';
  return `
    <div class="stat-box">
      <div class="stat-label">Buyer Pays</div>
      <div class="stat-value">${fmt(r.buyerTotal)}</div>
      <div class="stat-sub">${state.payment === 'cc' ? 'Credit Card' : 'PromptPay'} · ${dlvLabel}</div>
    </div>
    <div class="stat-box">
      <div class="stat-label">Seller Receives</div>
      <div class="stat-value">${fmt(r.sellerReceives)}</div>
      <div class="stat-sub">${
        r.isAuction
          ? (r.sellerFeeShare > 0 ? `Auction — ${fmtPct(C.auctionSellerFeeRate)} of BSA rate` : 'Auction — seller lists free')
          : r.isConsign ? `After fee + ${fmtPct(C.consignPayback)} payback`
          : 'After Buy-Sell fee'
      }</div>
    </div>
    <div class="stat-box highlight-box">
      <div class="stat-label">Platform Net</div>
      <div class="stat-value">${fmt(r.platformNet)}</div>
      <div class="stat-sub">GM ${fmtPct(r.platformGM)}</div>
    </div>
    <div class="stat-box">
      <div class="stat-label">${txLabel} Fee (Buyer)</div>
      <div class="stat-value">${fmt(r.buyerFeeShare)}</div>
      <div class="stat-sub">${
        r.buyerFeeRate != null ? fmtPct(r.buyerFeeRate) : 'Flat'
      } · ${state.buyerTier}</div>
    </div>`;
}

// ─── Step-by-step breakdown (three-column) ────────────────────────────────────
function renderBreakdown(r, price) {
  const bracket      = getBracket(price);
  const bracketLabel = BRACKET_LABELS[BRACKETS.indexOf(bracket)];
  const buyerFeeRateStr = bsaRates[bracket].flat
    ? `฿${bsaRates[bracket].rates[TIER_IDX[state.buyerTier]]} flat`
    : fmtPct(bsaRates[bracket].rates[TIER_IDX[state.buyerTier]]);
  const sellerFeeRateStr = bsaRates[bracket].flat
    ? `฿${bsaRates[bracket].rates[TIER_IDX[state.sellerTier]]} flat`
    : fmtPct(bsaRates[bracket].rates[TIER_IDX[state.sellerTier]]);
  const buyerFeeFormula = bsaRates[bracket].flat
    ? `${buyerFeeRateStr} flat`
    : `${fmt(price)} × ${buyerFeeRateStr}`;
  const sellerFeeFormula = bsaRates[bracket].flat
    ? `${sellerFeeRateStr} flat`
    : `${fmt(price)} × ${sellerFeeRateStr}`;

  // Buyer column
  const buyerHtml = `<div>
    <div class="calc-col-title buyer">🛒 Buyer Calculation</div>
    ${calcLine('Listed Price (P0)', '', fmt(price))}
    ${calcLine(
      r.isAuction ? `Auction fee (${state.buyerTier}, ${buyerFeeRateStr})` : `Buyer fee (${state.buyerTier}, ${buyerFeeRateStr})`,
      buyerFeeFormula, fmt(r.buyerFeeShare), 'neg')}
    ${r.isConsign && r.consignExtra > 0
      ? calcLine(`Consign delivery fee (${fmtPct(C.consignExtraRate)})`,
          `${fmt(price)} × ${fmtPct(C.consignExtraRate)}`, fmt(r.consignExtra), 'neg')
      : ''}
    ${calcLine(r.isConsign ? 'Shipping' : 'Shipping (Deliver Now)', `฿${C.shippingCharge}`, fmt(r.shippingCharge), 'neg')}
    ${state.payment === 'pp' && r.ppDiscountAmt > 0
      ? calcLine(`PP discount (−${fmtPct(C.ppDisc)})`, `subtotal × ${fmtPct(C.ppDisc)}`, fmt(-r.ppDiscountAmt), 'pos')
      : ''}
    ${calcTotal('= Total Buyer Pays', fmt(r.buyerTotal))}
  </div>`;

  // Seller column
  const sellerHtml = `<div>
    <div class="calc-col-title seller">💼 Seller Calculation</div>
    ${calcLine('Listed Price (P0)', '', fmt(price))}
    ${r.isAuction && r.sellerFeeShare === 0
      ? calcLine('Seller fee (Auction — free to list)', 'Seller listed for free', '฿0.00', '')
      : r.isAuction
        ? calcLine(`Seller fee (Auction, ${fmtPct(C.auctionSellerFeeRate)} of BSA)`, `${sellerFeeFormula} × ${fmtPct(C.auctionSellerFeeRate)}`, fmt(-r.sellerFeeShare), 'neg')
        : calcLine(`Seller fee (${state.sellerTier}, ${sellerFeeRateStr})`, sellerFeeFormula, fmt(-r.sellerFeeShare), 'neg')}
    ${r.consignPayback > 0
      ? calcLine(`Consign payback (+${fmtPct(C.consignPayback)})`,
          `${fmt(price)} × ${fmtPct(C.consignPayback)}`, fmt(r.consignPayback), 'pos')
      : ''}
    ${calcTotal('= Net Received', fmt(r.sellerReceives))}
    <br>
    ${calcLine('Net Received', '', fmt(r.sellerReceives))}
    ${calcLine("Seller's Cost", '', fmt(-state.sellerCost), 'neg')}
    ${calcTotal('= Gross Profit', fmt(r.sellerProfit), r.sellerProfit >= 0 ? 'pos' : 'neg')}
  </div>`;

  // Platform column
  const payFeeLabel = state.payment === 'cc'
    ? `CC fee (${fmtPct(C.ccFee)} × buyer subtotal)`
    : `PP fee (${fmtPct(C.ppFee)} × buyer total)`;
  const payFeeBase  = state.payment === 'cc' ? r.buyerSubtotal : r.buyerTotal;
  const payFeeRate  = state.payment === 'cc' ? C.ccFee : C.ppFee;

  const platformHtml = `<div>
    <div class="calc-col-title platform">🏦 Platform Calculation</div>
    <div style="font-size:10px;color:var(--muted);margin-bottom:6px;">
      Bracket: ${bracketLabel}${r.isAuction ? (C.auctionSellerFeeRate > 0 ? ` · Auction (seller ${fmtPct(C.auctionSellerFeeRate)} of BSA)` : ' · Auction (seller free)') : ''}${r.isConsign ? ` · Consign extra: ${fmtPct(C.consignExtraRate)}` : ''}
    </div>
    ${r.isAuction
      ? `${calcLine(`Auction buyer fee (${state.buyerTier})`, buyerFeeFormula, fmt(r.buyerFeeShare), 'pos')}
         ${r.sellerFeeShare > 0 ? calcLine(`Auction seller fee (${fmtPct(C.auctionSellerFeeRate)} of BSA)`, `${sellerFeeFormula} × ${fmtPct(C.auctionSellerFeeRate)}`, fmt(r.sellerFeeShare), 'pos') : ''}`
      : `${calcLine(`Buyer fee (${state.buyerTier})`, buyerFeeFormula, fmt(r.buyerFeeShare), 'pos')}
         ${calcLine(`Seller fee (${state.sellerTier})`, sellerFeeFormula, fmt(r.sellerFeeShare), 'pos')}`}
    ${r.isConsign && r.consignExtra > 0
      ? calcLine(`Consign delivery fee (${fmtPct(C.consignExtraRate)})`,
          `${fmt(price)} × ${fmtPct(C.consignExtraRate)}`, fmt(r.consignExtra), 'pos')
      : ''}
    ${calcLine('= Total Fee Revenue', '', fmt(r.totalFeeRevenue))}
    <br>
    ${calcLine('Total Fee Revenue', '', fmt(r.totalFeeRevenue))}
    ${r.consignPayback > 0
      ? calcLine(`− Consign payback to seller (${fmtPct(C.consignPayback)})`,
          `${fmt(price)} × ${fmtPct(C.consignPayback)}`, fmt(-r.consignPayback), 'neg')
      : ''}
    ${r.shippingCollected > 0
      ? `${calcLine('+ Shipping collected from buyer', `฿${C.shippingCharge}`, fmt(r.shippingCollected), 'pos')}
         ${calcLine('− Courier / shipping cost', `฿${C.shippingCost}`, fmt(-r.shippingCost), 'neg')}`
      : calcLine('Shipping', 'Consign 7-Day — deferred, no courier cost now', '฿0.00', '')}
    ${calcLine(`− ${payFeeLabel}`, `${fmt(payFeeBase)} × ${fmtPct(payFeeRate)}`, fmt(-r.paymentFee), 'neg')}
    ${calcLine(`− VAT on fees (${fmtPct(C.vat)})`, `${fmt(r.totalFeeRevenue)} × ${fmtPct(C.vat)}`, fmt(-r.vatOnFee), 'neg')}
    ${state.payment === 'pp' && r.ppDiscountAmt > 0
      ? calcLine(`− PP discount given to buyer (${fmtPct(C.ppDisc)})`,
          `${fmt(r.buyerSubtotal)} × ${fmtPct(C.ppDisc)}`, fmt(-r.ppDiscountAmt), 'neg')
      : ''}
    ${calcTotal(`= Platform Net (GM ${fmtPct(r.platformGM)})`, fmt(r.platformNet), r.platformNet >= 0 ? 'pos' : 'neg')}
  </div>`;

  return buyerHtml + sellerHtml + platformHtml;
}

// ─── Editable BSA rate table ──────────────────────────────────────────────────
function renderBSAEditTable() {
  const tbody = document.querySelector('#bsaEditTable tbody');
  let html = '';
  BRACKETS.forEach((b, bi) => {
    const entry = bsaRates[b];
    html += `<tr>
      <td>${BRACKET_LABELS[bi]}</td>
      ${TIERS.map((t, ti) => {
        const val = entry.flat ? entry.rates[ti] : +(entry.rates[ti] * 100).toFixed(3);
        const cls = entry.flat ? 'flat-input' : '';
        return `<td><input type="number" class="rate-input ${cls}"
          value="${val}" min="0" max="${entry.flat ? 1000 : 100}" step="${entry.flat ? 1 : 0.01}"
          oninput="updateBSARate(${b},${ti},this.value,${entry.flat})"
          title="${t} tier, bracket ${b}"></td>`;
      }).join('')}
    </tr>`;
  });
  tbody.innerHTML = html;
}

// ─── BSA fee reference table + summary cells ──────────────────────────────────
// Shared by Buy-Sell and Auction — both use the same per-tier rates.
// Highlights buyer column (gold) and seller column (orange). Below the table,
// two summary cells show the active-bracket rate for each party.
function renderFeeTable(price) {
  const activeBracket = getBracket(price);
  let html = '';
  BRACKETS.forEach((b, i) => {
    const isActive = b === activeBracket;
    const entry    = bsaRates[b];
    html += `<tr class="${isActive ? 'active-row' : ''}">
      <td>${BRACKET_LABELS[i]}</td>
      ${entry.rates.map((rate, ti) => {
        const val      = entry.flat ? `฿${rate}` : fmtPct(rate);
        const isBuyer  = TIERS[ti] === state.buyerTier  && isActive;
        const isSeller = TIERS[ti] === state.sellerTier && isActive;
        let style = '';
        if (isBuyer && isSeller)
          style = 'style="background:linear-gradient(90deg,#D5F5E3 50%,#FDEBD0 50%);font-weight:900;color:var(--navy);"';
        else if (isBuyer)
          style = 'style="color:var(--green);font-weight:900;"';
        else if (isSeller)
          style = 'style="color:#D35400;font-weight:900;"';
        return `<td ${style}>${val}</td>`;
      }).join('')}
    </tr>`;
  });
  document.querySelector('#feeTable tbody').innerHTML = html;

  // Summary cells — active bracket rate for buyer and seller
  const entry      = bsaRates[activeBracket];
  const buyerRate  = entry.flat ? `฿${entry.rates[TIER_IDX[state.buyerTier]]}` : fmtPct(entry.rates[TIER_IDX[state.buyerTier]]);
  const sellerRate = entry.flat ? `฿${entry.rates[TIER_IDX[state.sellerTier]]}` : fmtPct(entry.rates[TIER_IDX[state.sellerTier]]);
  const isAuction  = state.txType === 'auction';
  const auctFeeRate = C.auctionSellerFeeRate || 0;
  const auctSellerBSA = entry.rates[TIER_IDX[state.sellerTier]];
  const auctSellerEffective = entry.flat
    ? `฿${(auctSellerBSA * auctFeeRate).toFixed(2)}`
    : fmtPct(auctSellerBSA * auctFeeRate);
  const showAuctFree = isAuction && auctFeeRate === 0;
  document.getElementById('feeTableSummary').innerHTML = `
    <div style="flex:1;background:#D5F5E3;border:1px solid var(--green);border-radius:6px;padding:6px 10px;text-align:center;">
      <div style="font-size:10px;color:#1E8449;font-weight:600;">Buyer (${state.buyerTier})</div>
      <div style="font-size:16px;font-weight:900;color:var(--green);">${buyerRate}</div>
      <div style="font-size:10px;color:#1E8449;">${isAuction ? 'Auction' : 'Buy-Sell'}</div>
    </div>
    <div style="flex:1;background:${showAuctFree ? '#F8F9FA' : '#FDEBD0'};border:1px solid ${showAuctFree ? '#CCC' : '#D35400'};border-radius:6px;padding:6px 10px;text-align:center;">
      <div style="font-size:10px;color:${showAuctFree ? 'var(--muted)' : '#784212'};font-weight:600;">Seller (${state.sellerTier})</div>
      <div style="font-size:16px;font-weight:900;color:${showAuctFree ? 'var(--muted)' : '#D35400'};">${isAuction ? (showAuctFree ? 'Free' : auctSellerEffective) : sellerRate}</div>
      <div style="font-size:10px;color:${showAuctFree ? 'var(--muted)' : '#784212'};">${isAuction ? (showAuctFree ? 'Auction — lists free' : `Auction · ${fmtPct(auctFeeRate)} of BSA`) : 'Buy-Sell'}</div>
    </div>`;
}

// ─── PromptPay break-even callout ─────────────────────────────────────────────
function renderBreakeven() {
  const el       = document.getElementById('ppBreakeven');
  const ppDisc   = C.ppDisc;
  const breakeven = ppBreakevenDiscount(C);
  const extra     = ppDisc - breakeven;
  const absExtra  = Math.abs(extra);
  const formula   = `(CC ${fmtPct(C.ccFee)} − PP ${fmtPct(C.ppFee)}) ÷ (1 − PP ${fmtPct(C.ppFee)}) = ${fmtPct(breakeven)}`;

  let cls, msg;
  if (absExtra < 0.0001) {
    cls = 'be-exact';
    msg = `✓ Exactly at break-even: ${formula}.<br>Platform earns the same net whether buyer pays by CC or PP.`;
  } else if (extra > 0) {
    const subtotal  = state.price * 1.15;
    const extraCost = subtotal * extra;
    cls = 'be-above';
    msg = `⚠ Break-even discount = ${fmtPct(breakeven)} &nbsp;(${formula}).`
        + `<br>Your ${fmtPct(ppDisc)} discount is <strong>${fmtPct(extra)} above break-even</strong> — platform earns less on PP than CC.`
        + `<br>On a ~฿${Math.round(subtotal).toLocaleString()} subtotal, that extra costs ~<strong>${fmt(extraCost)}</strong> per PP transaction.`;
  } else {
    cls = 'be-below';
    msg = `↑ Break-even discount = ${fmtPct(breakeven)} &nbsp;(${formula}).`
        + `<br>Your ${fmtPct(ppDisc)} discount is <strong>${fmtPct(absExtra)} below break-even</strong> — platform earns slightly more on PP than CC.`;
  }

  el.className = 'breakeven-box visible ' + cls;
  el.innerHTML = msg;
}

// ─── Chain node flow diagram ──────────────────────────────────────────────────
function renderChain(chainResult) {
  const { nodes } = chainResult;
  let html = '';
  nodes.forEach((node, i) => {
    if (i > 0) html += `<div class="chain-arrow">›</div>`;
    const showVal   = node.profit != null ? node.profit
                    : node.receives != null ? node.receives
                    : node.boughtAt;
    const profitPct = node.boughtAt && node.profit != null
      ? ` (${fmtPct(node.profit / node.boughtAt)})` : '';
    html += `
      <div class="chain-node">
        <div class="chain-node-header" style="background:${node.color};">
          ${node.label}<br><small style="font-weight:400;opacity:0.85">${node.role}</small>
        </div>
        <div class="chain-node-body">
          ${node.listPrice != null ? `<div class="chain-row"><span class="cl">List Price</span><span class="cv">${fmt(node.listPrice)}</span></div>` : ''}
          ${node.boughtAt  != null ? `<div class="chain-row"><span class="cl">${node.gotCoinRefund ? 'Net Cost (ship. refunded)' : 'Total Paid (incl. ship.)'}</span><span class="cv">${fmt(node.boughtAt)}</span></div>` : ''}
          ${node.gotCoinRefund ? `<div class="chain-row" style="font-size:11px;color:#2980B9;"><span class="cl">🪙 Coins Refund</span><span class="cv">+${fmt(C.shippingCharge)}</span></div>` : ''}
          ${node.fee != null ? `<div class="chain-row"><span class="cl">Fee</span><span class="cv neg">${fmt(-node.fee)}</span></div>` : ''}
          ${node.ConsignPayback > 0 ? `<div class="chain-row" style="font-size:11px;color:#1E8449;"><span class="cl">🎁 Payback</span><span class="cv pos">+${fmt(node.ConsignPayback)}</span></div>` : ''}
          <div class="chain-row" style="margin-top:6px;padding-top:6px;border-top:1px solid #EEE;">
            <span class="cl">${node.profitLabel}</span>
            <span class="cv ${node.profit != null && node.profit >= 0 ? 'pos' : ''}">${showVal != null ? fmt(showVal) : '—'}${profitPct}</span>
          </div>
          ${node.profit != null ? `<div class="chain-profit-bar" style="width:${Math.min(100, Math.max(0, (node.profit / (node.listPrice || 1)) * 500))}%"></div>` : ''}
        </div>
      </div>`;
  });
  return html;
}

// ─── Chain step-by-step breakdown ────────────────────────────────────────────
function renderChainBreakdown(transactions) {
  if (!transactions || transactions.length === 0) return '';

  const isMultiHop      = transactions.length > 1;
  const isAuction       = transactions[0].tx.isAuction;
  const buyerFeeRateStr  = tx => tx.buyerFeeRate  != null ? fmtPct(tx.buyerFeeRate)  : 'flat';
  const sellerFeeRateStr = tx => tx.sellerFeeRate != null ? fmtPct(tx.sellerFeeRate) : 'flat';

  const rateRange = transactions.length > 1
    ? `${fmtPct(Math.min(...transactions.map(t => t.consignRate)))}–${fmtPct(Math.max(...transactions.map(t => t.consignRate)))}`
    : fmtPct(transactions[0].consignRate);
  const subProportion = C.consignExtraRate > 0 ? C.consignPayback / C.consignExtraRate : 0;
  const auctionSellerNote = isAuction && C.auctionSellerFeeRate > 0
    ? ` Auction seller fee: ${fmtPct(C.auctionSellerFeeRate)} of BSA rate.` : '';
  const introText = isMultiHop
    ? `Each hop is a full consign transaction with per-hop rates based on days remaining (${rateRange}).
       <strong>All buyers pay shipping upfront (฿${C.shippingCharge})</strong>. Intermediate buyers receive a coin/points refund,
       leaving them with net-zero shipping cost. Only the Final Buyer bears real shipping.
       Store A payback: ${fmtPct(C.consignPayback)}.${state.subsequentPayback
         ? ` Subsequent consignors: ${fmtPct(subProportion)} of each hop's consign rate (platform keeps ${fmtPct(1 - subProportion)}).`
         : ' No payback to subsequent consignors.'}${auctionSellerNote}`
    : `Direct consignment (Store A → Final Buyer). Rate: ${rateRange} (Day ${transactions[0].daysRemaining}).
       Buyer pays the consign fee plus shipping (฿${C.shippingCharge}).
       ${isAuction ? `Auction mode: ${C.auctionSellerFeeRate > 0 ? `seller pays ${fmtPct(C.auctionSellerFeeRate)} of BSA rate` : 'seller listed free'}, buyer pays their BSA rate.` : 'Buy-Sell mode: buyer and seller each pay their own tier\'s BSA rate.'}`;

  let html = `<div class="chain-intro">${introText}</div>`;

  transactions.forEach(({ step, seller, buyer, price, tx, sellerBuyIn, isDelivery, coinRefund, adjustedPlatNet, daysRemaining, consignRate }) => {
    const actualBuyerTotal  = tx.buyerTotal;  // shippingCharge already in buyerTotal
    const effectiveCost     = actualBuyerTotal - (coinRefund || 0);
    const hopShippingNet    = isDelivery ? (C.shippingCharge - C.shippingCost) : 0;
    const stepGrossRev      = tx.totalFeeRevenue + hopShippingNet;
    const prevCoinRefund    = step > 1 ? transactions[step - 2].coinRefund : 0;
    const paybackRate       = tx.consignPayback > 0 ? tx.consignPayback / price : 0;

    html += `
    <div class="chain-step">
      <div class="chain-step-header">
        <span class="chain-step-num">Step ${step}</span>
        <span class="chain-step-arrow">${seller} → ${buyer}</span>
        <span class="chain-step-price">List Price: ${fmt(price)}</span>
        <span style="font-size:10px;background:#FEF9E7;color:#7D4E00;border-radius:10px;padding:2px 8px;font-weight:700;">Day ${daysRemaining} · ${fmtPct(consignRate)}</span>
        ${!isDelivery && transactions.length > 1
          ? `<span style="font-size:10px;background:#EBF5FB;color:#1A5276;border-radius:10px;padding:2px 8px;font-weight:700;">Rights Transfer</span>`
          : `<span style="font-size:10px;background:#D5F5E3;color:#1E8449;border-radius:10px;padding:2px 8px;font-weight:700;">Physical Delivery</span>`}
      </div>
      <div class="chain-step-body">

        <div class="chain-step-col seller-col">
          <div class="chain-step-role">💼 ${seller} Receives</div>
          ${calcLine('List Price', '', fmt(price))}
          ${isAuction && tx.sellerFeeShare === 0
            ? `<div class="calc-line"><span class="cl">Seller Fee</span><span class="cf">Auction — listed free</span><span class="cv">฿0.00</span></div>`
            : isAuction
              ? calcLine(`Seller Fee (Auction, ${fmtPct(C.auctionSellerFeeRate)} of BSA)`,
                  `${fmt(price)} × ${sellerFeeRateStr(tx)} × ${fmtPct(C.auctionSellerFeeRate)}`, fmt(-tx.sellerFeeShare), 'neg')
              : calcLine(`Seller Fee (${sellerFeeRateStr(tx)})`,
                  `${fmt(price)} × ${sellerFeeRateStr(tx)}`, fmt(-tx.sellerFeeShare), 'neg')}
          ${tx.consignPayback > 0
            ? calcLine(`Consign Payback (+${fmtPct(paybackRate)})`,
                `${fmt(price)} × ${fmtPct(paybackRate)}`, fmt(tx.consignPayback), 'pos')
            : ''}
          ${calcTotal('= Net Received', fmt(tx.sellerReceives))}
          ${sellerBuyIn != null ? `
            <div style="margin-top:8px;padding-top:8px;border-top:1px dashed #DDD;">
              ${calcLine('Net Received', '', fmt(tx.sellerReceives))}
              ${prevCoinRefund > 0
                ? `${calcLine('🪙 Coin Refund (prev. purchase)', 'from platform', fmt(prevCoinRefund), 'pos')}
                   ${calcLine('Cash Paid (prev. step)', '', fmt(-(sellerBuyIn + prevCoinRefund)), 'neg')}`
                : calcLine('Cost (prev. step)', '', fmt(-sellerBuyIn), 'neg')}
              ${calcTotal('= Reseller Profit', fmt(tx.sellerProfit), tx.sellerProfit >= 0 ? 'pos' : 'neg')}
            </div>` : ''}
        </div>

        <div class="chain-step-col buyer-col">
          <div class="chain-step-role">🛒 ${buyer} Pays</div>
          ${calcLine('List Price', '', fmt(price))}
          ${isAuction
            ? calcLine(`Auction Fee (${buyerFeeRateStr(tx)})`,
                `${fmt(price)} × ${buyerFeeRateStr(tx)}`, fmt(tx.buyerFeeShare), 'neg')
            : calcLine(`Buyer Fee (${buyerFeeRateStr(tx)})`,
                `${fmt(price)} × ${buyerFeeRateStr(tx)}`, fmt(tx.buyerFeeShare), 'neg')}
          ${tx.consignExtra > 0
            ? calcLine(`Consign Fee (+${fmtPct(consignRate)}, Day ${daysRemaining})`,
                `${fmt(price)} × ${fmtPct(consignRate)}`, fmt(tx.consignExtra), 'neg')
            : ''}
          ${calcLine('Shipping (upfront)', `฿${C.shippingCharge} collected`, fmt(C.shippingCharge), 'neg')}
          ${tx.ppDiscountAmt > 0
            ? calcLine(`PP Discount (−${fmtPct(C.ppDisc)})`, `subtotal × ${fmtPct(C.ppDisc)}`, fmt(-tx.ppDiscountAmt), 'pos')
            : ''}
          ${calcTotal('= Total Cash Paid', fmt(actualBuyerTotal))}
          ${!isDelivery && coinRefund > 0 ? `
            <div style="margin-top:6px;padding-top:6px;border-top:1px dashed #BBD;">
              ${calcLine('🪙 Coins Refund (shipping)', 'returned as platform coins', fmt(coinRefund), 'pos')}
              ${calcTotal('= Net Effective Cost', fmt(effectiveCost))}
            </div>` : ''}
        </div>

        <div class="chain-step-col platform-col">
          <div class="chain-step-role">🏦 Platform Earns (Step ${step})</div>
          <div style="font-size:10px;color:var(--muted);margin-bottom:4px;">Fee revenue collected:</div>
          ${isAuction
            ? `${calcLine(`Auction buyer fee (${buyerFeeRateStr(tx)})`,
                `${fmt(price)} × ${buyerFeeRateStr(tx)}`, fmt(tx.buyerFeeShare), 'pos')}
               ${tx.sellerFeeShare > 0 ? calcLine(`Auction seller fee (${fmtPct(C.auctionSellerFeeRate)} of BSA)`,
                `${fmt(price)} × ${sellerFeeRateStr(tx)} × ${fmtPct(C.auctionSellerFeeRate)}`, fmt(tx.sellerFeeShare), 'pos') : ''}`
            : `${calcLine(`Buyer fee (${buyerFeeRateStr(tx)})`, `${fmt(price)} × ${buyerFeeRateStr(tx)}`, fmt(tx.buyerFeeShare), 'pos')}
               ${calcLine(`Seller fee (${sellerFeeRateStr(tx)})`, `${fmt(price)} × ${sellerFeeRateStr(tx)}`, fmt(tx.sellerFeeShare), 'pos')}`}
          ${tx.consignExtra > 0
            ? calcLine(`Consign Fee (+${fmtPct(consignRate)}, Day ${daysRemaining})`,
                `${fmt(price)} × ${fmtPct(consignRate)}`, fmt(tx.consignExtra), 'pos')
            : ''}
          ${isDelivery
            ? `${calcLine('Shipping Collected', `฿${C.shippingCharge} from buyer`, fmt(C.shippingCharge), 'pos')}
               ${calcLine('Courier Cost', `฿${C.shippingCost} paid to courier`, fmt(-C.shippingCost), 'neg')}
               ${calcLine('Shipping Net', `฿${C.shippingCharge} − ฿${C.shippingCost}`, fmt(hopShippingNet), hopShippingNet >= 0 ? 'pos' : 'neg')}`
            : `${calcLine('Shipping Collected', `฿${C.shippingCharge} from buyer`, fmt(C.shippingCharge), 'pos')}
               ${calcLine('🪙 Coins Issued to Buyer', 'refunded as platform coins', fmt(-coinRefund), 'neg')}
               ${calcLine('Shipping Net', 'collect & refund = zero', '฿0.00', '')}`}
          ${calcLine('= Fee Revenue', '', fmt(stepGrossRev), stepGrossRev >= 0 ? 'pos' : 'neg')}
          <br>
          <div style="font-size:10px;color:var(--muted);margin-bottom:4px;">Costs borne by platform:</div>
          ${state.payment === 'cc'
            ? calcLine(`CC Fee (${fmtPct(C.ccFee)} × buyer subtotal)`,
                `${fmt(tx.buyerSubtotal)} × ${fmtPct(C.ccFee)}`, fmt(-tx.paymentFee), 'neg')
            : calcLine(`PP Fee (${fmtPct(C.ppFee)} × buyer total)`,
                `${fmt(tx.buyerTotal)} × ${fmtPct(C.ppFee)}`, fmt(-tx.paymentFee), 'neg')}
          ${calcLine(`VAT on Fee Revenue (${fmtPct(C.vat)})`,
              `${fmt(tx.totalFeeRevenue)} × ${fmtPct(C.vat)}`, fmt(-tx.vatOnFee), 'neg')}
          ${tx.consignPayback > 0
            ? calcLine(`Consign Payback to Seller (${fmtPct(paybackRate)})`,
                `${fmt(price)} × ${fmtPct(paybackRate)}`, fmt(-tx.consignPayback), 'neg')
            : ''}
          ${state.payment === 'pp' && tx.ppDiscountAmt > 0
            ? calcLine(`PP discount to buyer (${fmtPct(C.ppDisc)})`,
                `${fmt(tx.buyerSubtotal)} × ${fmtPct(C.ppDisc)}`, fmt(-tx.ppDiscountAmt), 'neg')
            : ''}
          ${calcTotal('= Platform Net', fmt(adjustedPlatNet), adjustedPlatNet >= 0 ? 'pos' : 'neg')}
        </div>

      </div>
    </div>`;
  });

  // Chain-wide summary totals
  const totalPlatform     = transactions.reduce((s, t) => s + t.adjustedPlatNet, 0);
  const totalCoinsIssued  = transactions.reduce((s, t) => s + (t.coinRefund || 0), 0);
  const totalConsignExtra = transactions.reduce((s, t) => s + t.tx.consignExtra, 0);
  const finalTx           = transactions[transactions.length - 1];
  const finalBuyerPaid    = finalTx.tx.buyerTotal;
  const origSellerGets    = transactions[0].tx.sellerReceives;
  const intermediateCount = transactions.filter(t => !t.isDelivery).length;
  const hopLabel          = transactions.length === 1 ? '1 transaction' : `${transactions.length} hops combined`;
  const deliveryShipNet   = C.shippingCharge - C.shippingCost;

  html += `<div class="chain-total-summary">
    <div class="chain-total-row">
      <span class="ct-label">🛒 Final Buyer Total Paid (incl. shipping ฿${C.shippingCharge})</span>
      <span class="ct-val">${fmt(finalBuyerPaid)}</span>
    </div>
    <div class="chain-total-row">
      <span class="ct-label">💼 Store A Net Received</span>
      <span class="ct-val">${fmt(origSellerGets)}</span>
    </div>
    <div class="chain-total-row">
      <span class="ct-label">↳ Consign Fees (${transactions.length} hop${transactions.length > 1 ? 's' : ''}, variable day rates)</span>
      <span class="ct-val">${fmt(totalConsignExtra)}</span>
    </div>
    ${isMultiHop && totalCoinsIssued > 0 ? `
    <div class="chain-total-row">
      <span class="ct-label">🪙 Coins/Points Issued (shipping refunds × ${intermediateCount} intermediate buyer${intermediateCount > 1 ? 's' : ''})</span>
      <span class="ct-val neg">${fmt(-totalCoinsIssued)}</span>
    </div>` : ''}
    <div class="chain-total-row">
      <span class="ct-label">🚚 Shipping Net (one delivery: ฿${C.shippingCharge} − ฿${C.shippingCost})</span>
      <span class="ct-val">${fmt(deliveryShipNet)}</span>
    </div>
    <div class="chain-total-row highlight">
      <span>🏦 Platform Net (${hopLabel})</span>
      <span class="${totalPlatform >= 0 ? 'pos' : 'neg'}">${fmt(totalPlatform)}</span>
    </div>
  </div>`;

  return html;
}
