// ─── Save / Load / Export / Import ───────────────────────────────────────────
// All functions reference global `state`, `C`, `bsaRates` from ui.js.

const LS_KEY = 'swibswap_fee_presets';

function getSnapshot(name) {
  readConstants(); // sync C from current DOM inputs
  return {
    name:    name || 'Preset',
    savedAt: new Date().toISOString(),
    version: '1.0',
    constants: { ...C },
    bsaRates:  deepClone(bsaRates),
    simulation: {
      price:             state.price,
      buyerTier:         state.buyerTier,
      sellerTier:        state.sellerTier,
      txType:            state.txType,
      deliveryMode:      state.deliveryMode,
      payment:           state.payment,
      sellerCost:        state.sellerCost,
      chainHops:         state.chainHops.map(h => ({
        daysRemaining: h.daysRemaining,
        sellerTier:    h.sellerTier || 'platinum',
        buyerTier:     h.buyerTier  || 'gold',
        txType:        h.txType    || 'buysell',
        payment:       h.payment   || 'cc',
      })),
      markup:            state.markup,
      subsequentPayback: state.subsequentPayback,
    },
  };
}

function applySnapshot(snap) {
  if (snap.constants) {
    C = {
      ...DEFAULT_CONSTANTS,
      consignDecayRates: DEFAULT_CONSTANTS.consignDecayRates.slice(),
      ...snap.constants,
    };
    if (!C.consignDecayRates) C.consignDecayRates = DEFAULT_CONSTANTS.consignDecayRates.slice();
    document.getElementById('cShipping').value      = C.shippingCharge;
    document.getElementById('cShippingCost').value  = C.shippingCost;
    document.getElementById('cCC').value            = (C.ccFee             * 100).toFixed(2);
    document.getElementById('cPP').value            = (C.ppFee             * 100).toFixed(2);
    document.getElementById('cVAT').value           = (C.vat               * 100).toFixed(2);
    document.getElementById('cConsignExtra').value      = (C.consignExtraRate         * 100).toFixed(2);
    document.getElementById('cAuctionSellerFee').value  = ((C.auctionSellerFeeRate || 0) * 100).toFixed(1);
    const ppPct = C.ppDisc * 100;
    document.getElementById('ppDiscMain').value      = ppPct;
    document.getElementById('ppDiscVal').textContent = ppPct.toFixed(1) + '%';
    // Force decay graph re-render with loaded rates
    const dgSection = document.getElementById('decayGraphSection');
    if (dgSection) dgSection.innerHTML = '';
  }
  if (snap.bsaRates) { bsaRates = deepClone(snap.bsaRates); renderBSAEditTable(); }
  if (snap.simulation) {
    const s = snap.simulation;
    document.getElementById('price').value      = s.price;
    document.getElementById('sellerCost').value = s.sellerCost;
    setBuyerTier(s.buyerTier    || 'gold');
    setSellerTier(s.sellerTier  || 'platinum');
    setTxType(s.txType === 'bsa' ? 'buysell' : (s.txType || 'buysell'));
    setDeliveryMode(s.deliveryMode || 'deliver');
    setPayment(s.payment || 'cc');
    if (s.chainHops) state.chainHops = s.chainHops;
    if (s.markup != null) {
      state.markup = s.markup;
      const markupEl = document.getElementById('markup');
      if (markupEl) markupEl.value = Math.round(s.markup * 100);
    }
    if (s.subsequentPayback != null) state.subsequentPayback = s.subsequentPayback;
  }
  recalc();
}

function getSaves()      { return JSON.parse(localStorage.getItem(LS_KEY) || '[]'); }
function putSaves(arr)   { localStorage.setItem(LS_KEY, JSON.stringify(arr)); }

function refreshSaveList() {
  const saves = getSaves();
  const sel   = document.getElementById('savedList');
  sel.innerHTML = '<option value="">— Saved presets —</option>' +
    saves.map(s => `<option value="${s.name}">${s.name} (${s.savedAt.slice(0, 10)})</option>`).join('');
}

function savePreset() {
  const name = document.getElementById('saveName').value.trim() || 'Preset';
  const snap = getSnapshot(name);
  const saves = getSaves();
  const idx = saves.findIndex(s => s.name === name);
  if (idx >= 0) saves[idx] = snap; else saves.push(snap);
  putSaves(saves);
  refreshSaveList();
  document.getElementById('savedList').value = name;
  const msg = document.getElementById('saveMsg');
  msg.classList.add('show');
  setTimeout(() => msg.classList.remove('show'), 2000);
}

function loadPreset() {
  const name = document.getElementById('savedList').value;
  if (!name) return;
  const snap = getSaves().find(s => s.name === name);
  if (snap) applySnapshot(snap);
}

function deletePreset() {
  const name = document.getElementById('savedList').value;
  if (!name) return;
  if (!confirm(`Delete preset "${name}"?`)) return;
  putSaves(getSaves().filter(s => s.name !== name));
  refreshSaveList();
}

function exportJSON() {
  const name = document.getElementById('saveName').value.trim() || 'swibswap_fees';
  const snap = getSnapshot(name);
  const blob = new Blob([JSON.stringify(snap, null, 2)], { type: 'application/json' });
  const url  = URL.createObjectURL(blob);
  const a    = Object.assign(document.createElement('a'), {
    href: url,
    download: `${name.replace(/\s+/g, '_')}_${snap.savedAt.slice(0, 10)}.json`,
  });
  a.click();
  URL.revokeObjectURL(url);
}

function importJSON(input) {
  const file = input.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = e => {
    try {
      const snap = JSON.parse(e.target.result);
      if (!snap.version) throw new Error('Not a SwibSwap settings file');
      applySnapshot(snap);
      if (snap.name) document.getElementById('saveName').value = snap.name;
    } catch (err) { alert('Import failed: ' + err.message); }
  };
  reader.readAsText(file);
  input.value = '';
}

function syncToCashflow() {
  localStorage.setItem('swibswap_fee_active', JSON.stringify(getSnapshot('fee-active')));
  const msg = document.getElementById('syncMsg');
  msg.style.display = 'block';
  setTimeout(() => msg.style.display = 'none', 2500);
}

function exportCSV() {
  const d = new Date().toISOString().slice(0, 10);
  let csv = `SwibSwap Fee Rates Export,${d}\n\nBSA Fee Rates\nBracket,User,Silver,Gold,Platinum\n`;
  const labels = ['< ฿100 (flat THB)', '฿100–999', '฿1000–9999', '฿10000+'];
  BRACKETS.forEach((b, i) => {
    const e    = bsaRates[b];
    const vals = e.rates.map(r => e.flat ? r : (r * 100).toFixed(3) + '%');
    csv += `"${labels[i]}",${vals.join(',')}\n`;
  });
  csv += '\nPlatform Constants\n';
  csv += `Shipping Charged,${C.shippingCharge}\nShipping Cost,${C.shippingCost}\n`;
  csv += `CC Fee,${(C.ccFee * 100).toFixed(2)}%\nPromptPay Fee,${(C.ppFee * 100).toFixed(2)}%\n`;
  csv += `PP Buyer Discount,${(C.ppDisc * 100).toFixed(2)}%\nVAT on Fees,${(C.vat * 100).toFixed(2)}%\n`;
  csv += `Consign 7-Day Extra,${(C.consignExtraRate * 100).toFixed(2)}%\n`;
  const blob = new Blob(['﻿' + csv], { type: 'text/csv;charset=utf-8' });
  const url  = URL.createObjectURL(blob);
  const a    = Object.assign(document.createElement('a'), { href: url, download: `swibswap_fee_rates_${d}.csv` });
  a.click();
  URL.revokeObjectURL(url);
}
