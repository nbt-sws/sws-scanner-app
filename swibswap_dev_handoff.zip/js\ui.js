// ─── Mutable globals ──────────────────────────────────────────────────────────
let bsaRates = deepClone(DEFAULT_BSA);
let C        = Object.assign({}, DEFAULT_CONSTANTS, {
  consignDecayRates: DEFAULT_CONSTANTS.consignDecayRates.slice(),
});

let state = {
  price:              10000,
  buyerTier:          'gold',
  sellerTier:         'platinum',
  txType:             'buysell',      // 'buysell' | 'auction'
  deliveryMode:       'deliver',      // 'deliver' | 'consign'
  payment:            'cc',           // 'cc' | 'pp'
  sellerCost:         8000,
  chainHops:          [{ daysRemaining: 7, sellerTier: 'platinum', buyerTier: 'gold', txType: 'buysell', payment: 'cc', buyerMode: 'buyout', buyerDays: 7 }],
  markup:             0.10,
  subsequentPayback:  false,
};

// ─── Read platform constants from DOM ─────────────────────────────────────────
function readConstants() {
  C.shippingCharge   = parseFloat(document.getElementById('cShipping').value)         || 0;
  C.shippingCost     = parseFloat(document.getElementById('cShippingCost').value)     || 0;
  C.ccFee            = (parseFloat(document.getElementById('cCC').value)              || 0) / 100;
  C.ppFee            = (parseFloat(document.getElementById('cPP').value)              || 0) / 100;
  C.ppDisc           = (parseFloat(document.getElementById('ppDiscMain').value)       || 0) / 100;
  C.vat              = (parseFloat(document.getElementById('cVAT').value)             || 0) / 100;
  C.consignExtraRate    = (parseFloat(document.getElementById('cConsignExtra').value)        || 0) / 100;
  C.consignPayback      = (parseFloat(document.getElementById('cConsignPayback').value)      || 0) / 100;
  C.auctionSellerFeeRate = (parseFloat(document.getElementById('cAuctionSellerFee').value)   || 0) / 100;
  // Decay rates — inputs are rendered dynamically by renderDecayGraph
  if (!C.consignDecayRates) C.consignDecayRates = DEFAULT_CONSTANTS.consignDecayRates.slice();
  for (let d = 1; d <= 7; d++) {
    const el = document.getElementById(`decayDay${d}`);
    if (el) C.consignDecayRates[d - 1] = (parseFloat(el.value) || 0) / 100;
  }
}

function syncConstantsToDOM(src) {
  src = src || DEFAULT_CONSTANTS;
  document.getElementById('cShipping').value       = src.shippingCharge;
  document.getElementById('cShippingCost').value   = src.shippingCost;
  document.getElementById('cCC').value             = (src.ccFee            * 100).toFixed(2);
  document.getElementById('cPP').value             = (src.ppFee            * 100).toFixed(2);
  document.getElementById('cVAT').value            = (src.vat              * 100).toFixed(2);
  document.getElementById('cConsignExtra').value      = (src.consignExtraRate    * 100).toFixed(2);
  document.getElementById('cConsignPayback').value    = (src.consignPayback     * 100).toFixed(2);
  document.getElementById('cAuctionSellerFee').value  = ((src.auctionSellerFeeRate || 0) * 100).toFixed(1);
  const ppPct = src.ppDisc * 100;
  document.getElementById('ppDiscMain').value      = ppPct;
  document.getElementById('ppDiscVal').textContent = ppPct.toFixed(1) + '%';
  // Decay rates synced when graph re-renders (it reads from C directly)
}

function resetConstants() {
  C = Object.assign({}, DEFAULT_CONSTANTS, {
    consignDecayRates: DEFAULT_CONSTANTS.consignDecayRates.slice(),
  });
  syncConstantsToDOM(DEFAULT_CONSTANTS);
  recalc();
}

function resetBSA() {
  bsaRates = deepClone(DEFAULT_BSA);
  renderBSAEditTable();
  recalc();
}

function updateBSARate(bracket, tierIdx, value, isFlat) {
  const numVal = parseFloat(value);
  if (isNaN(numVal)) return;
  bsaRates[bracket].rates[tierIdx] = isFlat ? numVal : numVal / 100;
  recalc();
}

function toggleCollapsible(id) {
  document.getElementById(id + 'Toggle').classList.toggle('open');
  document.getElementById(id + 'Body').classList.toggle('open');
}

// ─── Consignment chain management ─────────────────────────────────────────────
function addConsignee() {
  if (state.chainHops.length >= 7) return;
  const last = state.chainHops[state.chainHops.length - 1];
  state.chainHops.push({
    daysRemaining: last.daysRemaining,
    sellerTier:    last.sellerTier || state.sellerTier,
    buyerTier:     last.buyerTier  || 'gold',
    txType:        last.txType     || state.txType,
    payment:       last.payment    || state.payment,
    buyerMode:     'buyout',
    buyerDays:     7,
  });
  recalc();
}

function setHopTier(idx, tier) {
  if (state.chainHops[idx]) { state.chainHops[idx].buyerTier = tier; recalc(); }
}

function setHopSellerTier(idx, tier) {
  if (state.chainHops[idx]) { state.chainHops[idx].sellerTier = tier; recalc(); }
}

function setHopTxType(idx, type) {
  if (state.chainHops[idx]) { state.chainHops[idx].txType = type; recalc(); }
}

function setHopPayment(idx, method) {
  if (state.chainHops[idx]) { state.chainHops[idx].payment = method; recalc(); }
}

function toggleSubsequentPayback(checked) {
  state.subsequentPayback = !!checked;
  recalc();
}

function deleteConsignee(idx) {
  if (idx === 0 || state.chainHops.length <= 1) return;
  state.chainHops.splice(idx, 1);
  recalc();
}

function setHopDays(idx, val) {
  const days = Math.max(1, Math.min(7, parseInt(val) || 7));
  if (state.chainHops[idx]) {
    state.chainHops[idx].daysRemaining = days;
    recalc();
  }
}

function setFinalBuyerMode(idx, mode) {
  if (state.chainHops[idx]) { state.chainHops[idx].buyerMode = mode; recalc(); }
}

function setFinalBuyerDays(val) {
  const days = Math.max(1, Math.min(7, parseInt(val) || 7));
  const last = state.chainHops[state.chainHops.length - 1];
  if (last) { last.buyerDays = days; recalc(); }
}

// ─── Decay rate management ────────────────────────────────────────────────────
function updateDecayRate(idx, val) {
  const rate = Math.max(0, parseFloat(val) || 0) / 100;
  if (!C.consignDecayRates) C.consignDecayRates = DEFAULT_CONSTANTS.consignDecayRates.slice();
  C.consignDecayRates[idx] = rate;
  // Re-render only the decay graph bars (inputs stay focused)
  _refreshDecayBars();
  recalc();
}

function resetDecayRates() {
  C.consignDecayRates = DEFAULT_CONSTANTS.consignDecayRates.slice();
  const section = document.getElementById('decayGraphSection');
  if (section) section.innerHTML = renderDecayGraph(C);
  recalc();
}

function _refreshDecayBars() {
  const rates   = C.consignDecayRates;
  const maxRate = Math.max(...rates);
  for (let d = 1; d <= 7; d++) {
    const fill = document.getElementById(`decayFill${d}`);
    const val  = document.getElementById(`decayValLabel${d}`);
    if (fill) fill.style.height = (maxRate > 0 ? rates[d-1] / maxRate * 100 : 0) + '%';
    if (val)  val.textContent   = (rates[d-1] * 100).toFixed(2) + '%';
  }
}

// ─── Main recalculate ─────────────────────────────────────────────────────────
function recalc() {
  // ── Read inputs ─────────────────────────────────────────────────────────────
  state.price      = parseFloat(document.getElementById('price').value)      || 100;
  state.sellerCost = parseFloat(document.getElementById('sellerCost').value) || 0;
  // markup input is rendered inside chain builder — read only if it exists
  const markupInput = document.getElementById('markup');
  if (markupInput) state.markup = (parseFloat(markupInput.value) || 10) / 100;

  readConstants();
  renderBreakeven();

  const isConsign = state.deliveryMode === 'consign';

  // ── Shipping margin warning ──────────────────────────────────────────────────
  const warnEl  = document.getElementById('constWarning');
  const warnTxt = document.getElementById('constWarnText');
  if (state.deliveryMode === 'deliver' && C.shippingCharge !== C.shippingCost) {
    warnEl.style.display = 'flex';
    const diff = C.shippingCharge - C.shippingCost;
    warnTxt.textContent = diff > 0
      ? `Platform earns ฿${diff.toFixed(0)} on shipping (charged ฿${C.shippingCharge} / cost ฿${C.shippingCost})`
      : `Platform LOSES ฿${Math.abs(diff).toFixed(0)} on shipping (charged ฿${C.shippingCharge} / cost ฿${C.shippingCost})`;
  } else {
    warnEl.style.display = 'none';
  }

  // Grey out seller-tier group in auction mode
  const sellerGroup = document.getElementById('sellerTierGroup');
  if (sellerGroup) sellerGroup.style.opacity = state.txType === 'auction' ? '0.4' : '1';

  // ── Single-transaction calc (always; used for fee table & non-consign dashboard) ──
  const singleC = isConsign
    ? Object.assign({}, C, { consignExtraRate: getConsignRate(state.chainHops[0].daysRemaining, C) })
    : C;
  const r = calc(
    state.price, state.buyerTier, state.sellerTier, state.txType,
    state.deliveryMode, state.payment, state.sellerCost, 0,
    singleC, bsaRates
  );

  // ── Chain result — computed early so it can drive both the dashboard and chain sections ──
  const chainResult = isConsign ? calcChain(
    state.price, state.buyerTier, state.sellerTier, state.txType,
    state.payment, state.chainHops, state.markup, 0,
    C, bsaRates, state.subsequentPayback
  ) : null;

  // ── Summary dashboard (3 cards + stat boxes) ────────────────────────────────
  if (isConsign && chainResult) {
    const { transactions } = chainResult;
    const finalTx  = transactions[transactions.length - 1];
    const firstTx  = transactions[0];
    const totalPlat = transactions.reduce((s, t) => s + t.adjustedPlatNet, 0);

    document.getElementById('buyerLabel').textContent    = '🛒 Final Buyer Pays';
    document.getElementById('sellerLabel').textContent   = '💼 Store A Receives';
    document.getElementById('platformLabel').textContent = '🏦 Platform Earns (Chain)';
    document.getElementById('buyerTotal').textContent    = fmt(finalTx.tx.buyerTotal);
    document.getElementById('sellerNet').textContent     = fmt(firstTx.tx.sellerReceives);
    document.getElementById('platformNet').textContent   = fmt(totalPlat);
    document.getElementById('buyerBody').innerHTML       = renderBuyerChain(transactions, C);
    document.getElementById('sellerBody').innerHTML      = renderSellerChain(transactions, state.price, state.sellerCost, C);
    document.getElementById('platformBody').innerHTML    = renderPlatformChain(transactions, C);
    document.getElementById('statBoxes').innerHTML       = renderStatsChain(chainResult, C);
  } else {
    document.getElementById('buyerLabel').textContent    = '🛒 Buyer Sees';
    document.getElementById('sellerLabel').textContent   = '💼 Seller Gets';
    document.getElementById('platformLabel').textContent = '🏦 Platform Earns';
    document.getElementById('buyerTotal').textContent    = fmt(r.buyerTotal);
    document.getElementById('sellerNet').textContent     = fmt(r.sellerReceives);
    document.getElementById('platformNet').textContent   = fmt(r.platformNet);
    document.getElementById('buyerBody').innerHTML       = renderBuyer(r, state.price);
    document.getElementById('sellerBody').innerHTML      = renderSeller(r, state.price);
    document.getElementById('platformBody').innerHTML    = renderPlatform(r);
    document.getElementById('statBoxes').innerHTML       = renderStats(r);
  }

  renderFeeTable(state.price);

  // ── Show / hide sections based on delivery mode ───────────────────────────────
  const bdSection = document.getElementById('breakdownSection');
  if (bdSection) bdSection.style.display = isConsign ? 'none' : '';
  if (!isConsign) {
    document.getElementById('breakdownBody').innerHTML = renderBreakdown(r, state.price);
  }

  const markupCtrl = document.getElementById('markupControl');
  if (markupCtrl) markupCtrl.style.display = (isConsign && state.chainHops.length > 1) ? '' : 'none';

  document.getElementById('chainBuilderSection').style.display    = isConsign ? '' : 'none';
  document.getElementById('decayGraphSectionWrap').style.display  = isConsign ? '' : 'none';
  document.getElementById('chainFlowSection').style.display       = isConsign ? '' : 'none';
  document.getElementById('chainCalcSection').style.display       = isConsign ? '' : 'none';

  if (isConsign) {
    document.getElementById('chainBuilderBody').innerHTML =
      renderChainBuilder(state.chainHops, state.markup, C);

    // Decay graph — render once, then only update bars to preserve input focus
    const dgSection = document.getElementById('decayGraphSection');
    if (!dgSection.querySelector('.dg-col')) {
      dgSection.innerHTML = renderDecayGraph(C);
    } else {
      _refreshDecayBars();
    }

    // Reuse chainResult already computed above
    document.getElementById('chainFlow').innerHTML     = renderChain(chainResult);
    document.getElementById('chainCalcBody').innerHTML = renderChainBreakdown(chainResult.transactions);
    const hopCount = state.chainHops.length;
    const hopDesc  = hopCount === 1 ? 'Direct (Store A → Final Buyer)'
                   : `${hopCount - 1} Flip${hopCount > 2 ? 's' : ''} (${hopCount + 1} parties)`;
    document.getElementById('chainCalcHeader').textContent = `📊 Consign Chain — ${hopDesc}`;
  }
}

// ─── UI event setters ─────────────────────────────────────────────────────────
function setBuyerTier(tier) {
  state.buyerTier = tier;
  document.querySelectorAll('#buyerTierGroup .tier-btn').forEach(b => {
    b.className = 'tier-btn' + (b.dataset.tier === tier ? ` active-${tier}` : '');
  });
  recalc();
}

function setSellerTier(tier) {
  if (tier === 'user') return;
  state.sellerTier = tier;
  document.querySelectorAll('#sellerTierGroup .tier-btn').forEach(b => {
    b.className = 'tier-btn' + (b.dataset.tier === tier ? ` active-${tier}` : '');
  });
  recalc();
}

function setTxType(type) {
  state.txType = type;
  document.getElementById('txBuysell').classList.toggle('active', type === 'buysell');
  document.getElementById('txAuction').classList.toggle('active', type === 'auction');
  recalc();
}

function setDeliveryMode(mode) {
  state.deliveryMode = mode;
  document.getElementById('dlvDeliver').classList.toggle('active', mode === 'deliver');
  document.getElementById('dlvConsign').classList.toggle('active', mode === 'consign');
  recalc();
}

function setPayment(method) {
  state.payment = method;
  document.getElementById('payCC').classList.toggle('active', method === 'cc');
  document.getElementById('payPP').classList.toggle('active', method === 'pp');
  recalc();
}

// ─── File menu ───────────────────────────────────────────────────────────────
function toggleFileMenu() {
  document.getElementById('fileMenuDropdown').classList.toggle('open');
}
document.addEventListener('click', function(e) {
  if (!e.target.closest('#fileMenu'))
    document.getElementById('fileMenuDropdown').classList.remove('open');
});

// ─── Bootstrap ───────────────────────────────────────────────────────────────
document.getElementById('price').addEventListener('input', recalc);
document.getElementById('sellerCost').addEventListener('input', recalc);

syncConstantsToDOM(DEFAULT_CONSTANTS);
document.getElementById('price').value      = state.price;
document.getElementById('sellerCost').value = state.sellerCost;

renderBSAEditTable();
refreshSaveList();
recalc();
