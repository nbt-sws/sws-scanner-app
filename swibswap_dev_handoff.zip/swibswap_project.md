# SwibSwap — Developer Handoff Brief

**Platform:** Online digital vault for PSA-graded cards & collectibles (Thai market)  
**Core mechanic:** 7-day consignment rights trading — users buy/sell the *right to call the card*, not the physical card.  
**Finalized config:** `NBT_Rate_3_2026-05-08.json` — load this into the simulator to see live calculations.

> This document is a complete spec for implementing SwibSwap's fee and transaction logic.  
> The accompanying simulator (`swibswap_fee_gui.html`) is a working reference implementation — every formula here is mirrored exactly in `js/calc.js`. Use it to verify any calculation.

---

## File Inventory

| File | Purpose |
|------|---------|
| `swibswap_fee_gui.html` | Fee simulator — main reference implementation |
| `swibswap_cashflow.html` | Cashflow projection model |
| `swibswap_quickstart.html` | Printable quick-start guide for the simulator |
| `js/config.js` | Simulator defaults — BSA rates, constants, tier/bracket metadata |
| `js/calc.js` | **Pure calculation engine** — `calc()`, `calcChain()`, `getConsignRate()` |
| `js/render.js` | HTML rendering — chain builder, breakdown cards, fee table |
| `js/storage.js` | Preset save/load, JSON export/import, CSV export |
| `js/ui.js` | State object, DOM event handlers, `recalc()` orchestrator |
| `NBT_Rate_3_2026-05-08.json` | **Finalized fee config** — load via Import JSON button |

**To run the simulator:** open `swibswap_fee_gui.html` in any browser, then import `NBT_Rate_3_2026-05-08.json` using the Import JSON button to load the finalized rates.

---

## Membership Tiers

| Tier | Monthly | Annual | Can List/Sell? | Can Consign? |
|------|---------|--------|----------------|--------------|
| User | Free | Free | No | No |
| Silver | ฿99 | ฿990 | Yes | Yes |
| Gold | ฿199 | ฿1,990 | Yes | Yes |
| Platinum | ฿429 | ฿3,999 | Yes | Yes |

**Rules:**
- User tier can buy, but cannot list items or consign.
- All paid tiers (Silver/Gold/Platinum) pay their own tier's BSA fee as both buyer and seller — there is no fee split.
- Annual pricing: Silver/Gold = "2 months free". Platinum annual corrects historical underpricing.

---

## Price Brackets

Bracket lookup determines which BSA rate row applies:

| Bracket Key | Price Range | Rate Type |
|-------------|------------|-----------|
| `100` | ≤ ฿100 | Flat THB per transaction |
| `15000` | ฿101 – ฿15,000 | % of price |
| `50000` | ฿15,001 – ฿50,000 | % of price |
| `50001` | ฿50,001 + | % of price |

```
getBracket(price):
  if price ≤ 100   → bracket 100
  if price ≤ 15000 → bracket 15000
  if price ≤ 50000 → bracket 50000
  else             → bracket 50001
```

---

## Finalized BSA Fee Table

Each party pays **their own tier's rate** independently. No fee sharing.

| Bracket | User | Silver | Gold | Platinum |
|---------|------|--------|------|----------|
| ≤ ฿100 (flat THB) | ฿6.00 | ฿5.00 | ฿3.50 | ฿2.25 |
| ฿101 – ฿15,000 | 15.0% | 8.0% | 6.5% | 3.5% |
| ฿15,001 – ฿50,000 | 13.0% | 7.5% | 6.0% | 3.5% |
| ฿50,001+ | 12.0% | 7.0% | 5.5% | 3.5% |

**Note:** Platinum rate is a flat **3.5%** across all percentage brackets — simplifying billing for the highest tier.

```
BSA fee for a party =
  if flat bracket:  rates[tierIndex]                 (THB amount)
  else:             price × rates[tierIndex]         (% of price)
```

Tier index: User=0, Silver=1, Gold=2, Platinum=3.

---

## Finalized Platform Constants

| Constant | Value | Description |
|----------|-------|-------------|
| `shippingCharge` | ฿50 | Charged to buyer on every transaction |
| `shippingCost` | ฿30 | Platform's actual courier cost |
| `ccFee` | 3.5% | Credit card processing fee (applied to buyer subtotal incl. shipping) |
| `ppFee` | 1.0% | PromptPay transfer fee (applied to buyer total after PP discount) |
| `ppDisc` | 2.5% | PromptPay buyer discount (platform subsidy on buyer subtotal) |
| `vat` | 7.0% | Thai VAT on platform fee revenue only — not on shipping (Revenue Code §78/1) |
| `consignExtraRate` | 2.5% | Max consign extra rate (Day 7); also used for single-transaction consign |
| `consignPayback` | 0% | Payback to first consignor — **zero in this config** |
| `auctionSellerFeeRate` | 0.5 | Auction sellers pay 50% of their normal BSA rate |

**Consign extra decay rates (index 0 = Day 1, index 6 = Day 7):**

| Day | 1 | 2 | 3 | 4 | 5 | 6 | 7 |
|-----|---|---|---|---|---|---|---|
| Rate | 0.42% | 0.60% | 1.00% | 1.50% | 1.80% | 2.00% | 2.50% |

The rate is looked up by `daysRemaining` and reflects urgency: sellers who list with more days remaining expose the buyer to a higher rate.

---

## Transaction Types

### 1. Buy-Sell

Standard direct purchase. Both parties pay their full BSA rate.

```
buyerFee    = BSAFee(price, buyerTier)
sellerFee   = BSAFee(price, sellerTier)

buyerSubtotal = price + buyerFee + shippingCharge (฿50)

if CC:
  buyerTotal    = buyerSubtotal
  ppDiscount    = 0
  paymentFee    = buyerSubtotal × 0.035

if PromptPay:
  ppDiscount    = buyerSubtotal × 0.025
  buyerTotal    = buyerSubtotal − ppDiscount
  paymentFee    = buyerTotal × 0.01

sellerReceives = price − sellerFee

totalFeeRevenue = buyerFee + sellerFee
shippingNet     = ฿50 − ฿30 = ฿20
vatOnFee        = totalFeeRevenue × 0.07
platformNet     = totalFeeRevenue + shippingNet − paymentFee − vatOnFee − ppDiscount
```

### 2. Auction

Buyer pays full BSA rate. Seller pays **50%** of their BSA rate (`auctionSellerFeeRate = 0.5`).

```
buyerFee     = BSAFee(price, buyerTier)
sellerFee    = BSAFee(price, sellerTier) × 0.5    ← halved for auction

# All other steps identical to Buy-Sell above
```

### 3. Consignment (Single Transaction)

Card stays in vault. Buyer pays BSA rate + consign extra fee. Seller pays BSA rate. No payback in this config.

```
consignRate   = consignDecayRates[daysRemaining − 1]  ← from decay table
consignExtra  = price × consignRate
consignPayback = price × 0  = 0                       ← zero in NBT_Rate_3

buyerSubtotal = price + buyerFee + consignExtra + shippingCharge

# Payment/seller/platform same as Buy-Sell, but:
totalFeeRevenue = buyerFee + sellerFee + consignExtra
sellerReceives  = price − sellerFee + consignPayback  = price − sellerFee
```

### 4. Final Buyer: Buyout vs Consign & Expire

The final buyer in a consignment chain chooses their mode:

**Buyout** (default):
- Treated internally as `deliveryMode = 'deliver'`
- `consignExtra = 0`, `consignPayback = 0`
- Buyer pays: `price + buyerFee + shippingCharge` only
- No consign extra, no payback to the preceding seller

**Consign & Expire**:
- Treated as `deliveryMode = 'consign'`
- The final hop charges **seller's consign rate + buyer's own consign rate** (additive)
- `consignExtra = price × (sellerDayRate + buyerDayRate)`
- Platform collects double consign fee on this hop
- Preceding seller receives payback (if `consignPayback > 0`; currently 0)

---

## Consignment Chain (Multi-Hop)

Models the rights-trading chain: **Store A → [Reseller 1 → … → Reseller N →] Final Buyer** (1–7 hops).

### Hop sequence

**Hop 1 — Store A → first buyer:**
- Store A is the original lister (seller)
- If only 1 hop total: the first buyer IS the Final Buyer, delivery applies
- If multiple hops: first buyer is Reseller 1, intermediate rules apply

**Intermediate hops (not the last):**
- `deliveryMode = 'consign'`, `deferShipping = true`
- Platform collects ฿50 shipping from buyer but **issues ฿50 coin refund** back
- Net shipping cost to intermediate buyer = ฿0
- Intermediate buyer's effective cost = `buyerTotal − ฿50`
- Their resale price = `effectiveCost × (1 + markup%)`

**Final delivery hop:**
- `deferShipping = false` — platform actually pays the ฿30 courier
- If **Buyout**: `deliveryMode = 'deliver'`, no consign extra charged
- If **Consign & Expire**: `deliveryMode = 'consign'`, combined seller+buyer consign rate applied

### Chain calculation steps

```
hop1Price  = listingPrice
hop1BuyIn  = 0  (Store A's cost basis is tracked separately for reporting)

for each hop i:
  consignRate   = decayRates[hop[i].daysRemaining − 1]
  isDelivery    = (i == lastHop)
  isBuyout      = isDelivery && hop[i].buyerMode != 'consignExpire'

  if isBuyout:
    deliveryMode = 'deliver'     → consignExtra = 0
  else:
    deliveryMode = 'consign'
    if isDelivery && consignExpire:
      combinedRate = sellerDayRate + buyerDayRate
    else:
      combinedRate = sellerDayRate

  tx = calc(hopPrice, hopBuyerTier, hopSellerTier, txType,
            deliveryMode, payment, buyIn, C, bsaRates,
            deferShipping = !isDelivery)

  coinRefund = isDelivery ? 0 : ฿50

  if not lastHop:
    nextBuyIn   = tx.buyerTotal − coinRefund
    nextPrice   = round(hopPrice × (1 + markup))
```

### Shipping net across the whole chain
- Platform collects ฿50 per hop from every buyer
- Platform refunds ฿50 per intermediate hop as coins
- Platform pays ฿30 courier once on the final delivery
- Net per chain = `฿50 (collected once, net of refunds) − ฿30 (courier) = ฿20`

---

## Payment Methods

| Method | Fee Basis | Buyer Discount |
|--------|-----------|----------------|
| Credit Card | 3.5% of `buyerSubtotal` | None |
| PromptPay | 1.0% of `buyerTotal` (after discount) | −2.5% of `buyerSubtotal` |

**Break-even PP discount** (where platform earns same net on CC vs PP):  
`breakEven = (ccFee − ppFee) / (1 − ppFee) = (0.035 − 0.01) / 0.99 ≈ 2.525%`  
At 2.5%, PP is very slightly below break-even — platform earns marginally less on PP vs CC, by design to drive adoption.

---

## Business Rules & Constraints

| Rule | Detail |
|------|--------|
| Max chain length | 7 hops |
| Min chain length | 1 hop (Store A → Final Buyer direct) |
| User tier | Can buy only — cannot list, consign, or resell |
| Reseller markup | Applied to the previous hop's sell price, not buy-in cost |
| Consign days | 1–7 — Day 7 = first listed, Day 1 = last day before expiry |
| Auction seller discount | 50% of normal BSA seller rate (auctionSellerFeeRate = 0.5) |
| Consign payback | ฿0 (consignPayback = 0 in finalized config) |
| VAT scope | Applied to platform fee revenue only (BSA fees + consign extra) — NOT on shipping |
| CC payment fee | On `buyerSubtotal` (before PP discount — CC has no discount) |
| PP payment fee | On `buyerTotal` (after PP discount has been applied) |
| Intermediate shipping | Coin/points refund model — net zero for intermediate buyers |

---

## Legal Framework (Thai Law)

| Area | Reference |
|------|-----------|
| Rights transfer (consignment) | Civil Code §303–313 |
| VAT tax point | Revenue Code §78(1) and §78/1 |
| Consignment VAT deferral | Revenue Dept Announcement (VAT) No. 8 |
| Digital contracts | E-Transaction Act §7, 8, 9 |
| Flipper (reseller) income type | Revenue Code §40(4)(ch) |

---

## Simulator Architecture

The fee simulator is a single-page app that serves as the **authoritative reference implementation**. Any discrepancy between this doc and `js/calc.js` — trust the code.

### Load order

```html
<script src="js/config.js">   <!-- constants, defaults, bracket metadata -->
<script src="js/calc.js">     <!-- pure calc functions — no DOM -->
<script src="js/render.js">   <!-- HTML string builders — no DOM writes -->
<script src="js/storage.js">  <!-- localStorage presets, JSON import/export -->
<script src="js/ui.js">       <!-- state object, event handlers, recalc() -->
```

### Key functions to port

| Function | File | What it does |
|----------|------|-------------|
| `getBracket(price)` | `calc.js` | Returns bracket key for a price |
| `getBSAFee(price, tier, bsaRates)` | `calc.js` | Returns THB fee for one party |
| `getConsignRate(daysRemaining, C)` | `calc.js` | Returns consign rate from decay table |
| `calc(price, buyerTier, sellerTier, txType, deliveryMode, payment, sellerCost, feeOverride, C, bsaRates, deferShipping)` | `calc.js` | Full single-transaction calculation — returns all line items |
| `calcChain(p0, buyerTier, sellerTier, txType, payment, chainHops, markup, feeOverride, C, bsaRates, subsequentPayback)` | `calc.js` | Full multi-hop chain calculation |

### State object (source of truth in ui.js)

```javascript
state = {
  price,            // listing price in THB
  buyerTier,        // 'user' | 'silver' | 'gold' | 'platinum'
  sellerTier,       // 'silver' | 'gold' | 'platinum'
  txType,           // 'buysell' | 'auction'
  deliveryMode,     // 'deliver' | 'consign'
  payment,          // 'cc' | 'pp'
  sellerCost,       // seller's cost basis (for profit display only)
  chainHops,        // array of hop objects, length 1–7
  markup,           // reseller markup, decimal (e.g. 0.08 = 8%)
  subsequentPayback // bool — give subsequent consignors proportional payback
}

// Each chainHop:
{
  daysRemaining,  // 1–7 — consign decay table index
  sellerTier,     // seller's BSA tier for this hop
  buyerTier,      // buyer's BSA tier for this hop
  txType,         // 'buysell' | 'auction' — falls back to state.txType
  payment,        // 'cc' | 'pp' — falls back to state.payment
  buyerMode,      // 'buyout' | 'consignExpire' — Final Buyer only
  buyerDays,      // 1–7 — Final Buyer's own consign days (consignExpire mode only)
}
```

---

## Worked Example — ฿15,000 Platinum/Platinum Auction, CC

Using finalized config (NBT_Rate_3):

```
price         = ฿15,000
bracket       = 15000  (price ≤ 15,000)
buyerTier     = platinum  → BSA rate = 3.5%
sellerTier    = platinum  → BSA rate = 3.5%, auction → × 0.5 = 1.75%

buyerFee      = 15,000 × 0.035       = ฿525.00
sellerFee     = 15,000 × 0.035 × 0.5 = ฿262.50
consignExtra  = 0  (deliver mode)

buyerSubtotal = 15,000 + 525 + 50    = ฿15,575.00
buyerTotal    = ฿15,575.00  (CC, no discount)
paymentFee    = 15,575 × 0.035       = ฿545.13

sellerReceives = 15,000 − 262.50     = ฿14,737.50

totalFeeRevenue = 525 + 262.50       = ฿787.50
vatOnFee        = 787.50 × 0.07      = ฿55.13
shippingNet     = 50 − 30            = ฿20.00
platformNet     = 787.50 + 20 − 545.13 − 55.13 − 0 = ฿207.24
```
