// ─── SwibSwap Fee Tables & Platform Constants ─────────────────────────────────
// EDIT HERE to change defaults. "Reset to Defaults" buttons read from these.

const DEFAULT_BSA = {
  //  bracket: { flat: bool, rates: [user, silver, gold, platinum] }
  100:   { flat: true,  rates: [3.5,   2.5,   1.5,   0.5  ] },  // flat THB  (≤ ฿100)
  15000: { flat: false, rates: [0.15,  0.075,  0.065, 0.04 ] },  // % of price (฿101–฿15,000)
  50000: { flat: false, rates: [0.135, 0.065,  0.055,  0.03] },  //             (฿15,001–฿50,000)
  50001: { flat: false, rates: [0.125, 0.055,  0.45, 0.02 ] },  //             (฿50,001+)
};

// Exponential decay: 0.005 * 6^((d-1)/6) — 0.50% at day 1, 3.00% at day 7
const DEFAULT_CONSIGN_DECAY = [0.0050, 0.0067, 0.0091, 0.0122, 0.0165, 0.0223, 0.0300];

const DEFAULT_CONSTANTS = {
  shippingCharge:      50,     // what buyer pays for "Deliver Now" (THB)
  shippingCost:        30,     // platform's actual courier cost (THB)
  ccFee:               0.035,  // credit card processing fee (3.5%)
  ppFee:               0.01,   // PromptPay transfer fee (1%)
  ppDisc:              0.02,   // PromptPay buyer discount given by platform
  vat:                 0.07,   // VAT on platform fees only, per Thai Revenue Code §78/1
  consignExtraRate:    0.03,   // single-transaction consign extra fee (day-7 / max rate)
  consignPayback:      0.01,   // payback to FIRST consignor (out of consignExtraRate collected)
  consignDecayRates:   DEFAULT_CONSIGN_DECAY.slice(),  // per-day consign rates, index 0 = day 1
  auctionSellerFeeRate: 0,     // fraction of BSA rate charged to seller in Auction (0 = free, 0.5 = 50%)
};

// ─── Tier & bracket metadata ──────────────────────────────────────────────────
const TIERS         = ['user', 'silver', 'gold', 'platinum'];
const TIER_IDX      = { user: 0, silver: 1, gold: 2, platinum: 3 };
const BRACKETS      = [100, 15000, 50000, 50001];
const BRACKET_LABELS = ['≤ ฿100 (flat)', '฿101 – ฿15,000', '฿15,001 – ฿50,000', '฿50,001+'];
